# Table 1（基线特征）+ 镉亚组分析
library(arrow); library(dplyr); library(survey)
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(survey.lonely.psu = "adjust")

df <- read_parquet(file.path(OUT, "analysis_clean.parquet"))
df <- df %>% mutate(
  age = RIDAGEYR,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White", "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  pir = INDFMPIR, bmi = BMXBMI,
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes")),
  strokeF = factor(stroke, levels = 0:1, labels = c("No stroke", "Stroke"))
)
df$wt_int <- df$WTINT2YR / 10

# ---------- Table 1（全分析样本，访谈权重） ----------
t1 <- df %>% filter(!is.na(wt_int), wt_int > 0, !is.na(strokeF))
des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_int, data = t1, nest = TRUE)

cont_vars <- c("age", "pir", "bmi", "BMXWAIST", "LBXTC", "LBDLDL", "LBDHDD", "LBXTR", "LBXGH", "LBXHSCRP")
cat_vars <- c("female", "race", "educ", "smoke", "diabetes", "hyperten", "alcohol")

tab1_rows <- list()
for (v in cont_vars) {
  m_all <- svymean(as.formula(paste0("~", v)), des, na.rm = TRUE)
  by <- svyby(as.formula(paste0("~", v)), ~strokeF, des, svymean, na.rm = TRUE)
  tt <- svyttest(as.formula(paste0(v, " ~ strokeF")), des)
  tab1_rows[[v]] <- data.frame(var = v, overall = sprintf("%.1f (%.2f)", coef(m_all), SE(m_all)),
    no_stroke = sprintf("%.1f (%.2f)", by[1, 2], by[1, 3]),
    stroke = sprintf("%.1f (%.2f)", by[2, 2], by[2, 3]), P = signif(tt$p.value, 3))
}
for (v in cat_vars) {
  tbl <- svytable(as.formula(paste0("~", v, " + strokeF")), des)
  pct <- prop.table(tbl, 2) * 100
  chi <- svychisq(as.formula(paste0("~", v, " + strokeF")), des, statistic = "Chisq")
  lv <- rownames(tbl)
  for (i in seq_along(lv)) {
    tab1_rows[[paste(v, lv[i])]] <- data.frame(var = paste0(v, ": ", lv[i]),
      overall = sprintf("%.1f%%", prop.table(margin.table(tbl, 1))[i] * 100),
      no_stroke = sprintf("%.1f%%", pct[i, 1]), stroke = sprintf("%.1f%%", pct[i, 2]),
      P = ifelse(i == 1, signif(chi$p.value, 3), NA))
  }
}
TAB1 <- bind_rows(tab1_rows)
write.csv(TAB1, file.path(OUT, "table1.csv"), row.names = FALSE, fileEncoding = "UTF-8")
cat("saved table1.csv  rows:", nrow(TAB1), "\n")

# ---------- 镉亚组分析（交互检验） ----------
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")
dd <- df %>% filter(if_all(all_of(c("LBXBCD", "wt_cd", "stroke", COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)),
                    wt_cd > 0)
dd <- dd %>% mutate(cdSD = LBXBCD / sd(LBXBCD),
                    agegrp = factor(age >= 60, levels = c(FALSE, TRUE), labels = c("<60", ">=60")))
subs <- list(
  Sex = "female", `Age group` = "agegrp", Diabetes = "diabetes",
  Hypertension = "hyperten", Smoking = "smoke"
)
sg_rows <- list()
for (snm in names(subs)) {
  sv <- subs[[snm]]
  for (lv in levels(dd[[sv]])) {
    sub <- dd %>% filter(.data[[sv]] == lv)
    covs <- setdiff(COV2, sv)
    des_s <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_cd, data = sub, nest = TRUE)
    m <- svyglm(as.formula(paste("stroke ~ cdSD +", paste(covs, collapse = " + "))),
                design = des_s, family = quasibinomial())
    s <- summary(m)$coefficients["cdSD", ]
    sg_rows[[paste(snm, lv)]] <- data.frame(subgroup = snm, level = lv,
      n = nrow(sub), OR = exp(s["Estimate"]), lo = exp(s["Estimate"] - 1.96 * s["Std. Error"]),
      hi = exp(s["Estimate"] + 1.96 * s["Std. Error"]), P = s["Pr(>|t|)"])
  }
  # 交互 P
  des_a <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_cd, data = dd, nest = TRUE)
  mint <- svyglm(as.formula(paste("stroke ~ cdSD *", sv, "+", paste(setdiff(COV2, sv), collapse = " + "))),
                 design = des_a, family = quasibinomial())
  s <- summary(mint)$coefficients
  itr <- grep("cdSD:|:cdSD", rownames(s), value = TRUE)
  p_int <- min(s[itr, "Pr(>|t|)"])
  for (lv in levels(dd[[sv]])) sg_rows[[paste(snm, lv)]]$P_interaction <- p_int
}
SG <- bind_rows(sg_rows)
write.csv(SG, file.path(OUT, "subgroup_cadmium.csv"), row.names = FALSE, fileEncoding = "UTF-8")
cat("saved subgroup_cadmium.csv\n")
print(SG %>% mutate(OR_CI = sprintf("%.2f(%.2f-%.2f)", OR, lo, hi)) %>%
        select(subgroup, level, n, OR_CI, P, P_interaction) %>% as.data.frame())
cat("DONE\n")
