# JoS 出版级森林图重绘（300 dpi）
library(dplyr); library(ggplot2)

# ---- Figure 2: 金属 × 卒中（Model 2）----
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

r <- read.csv(file.path(OUT, "or_results.csv"))
pd <- r %>% filter(direction == "Metals", model == "Model 2") %>%
  mutate(label = factor(exposure, levels = c("LBXBPB", "LBXBCD", "LBXTHG"),
                        labels = c("Blood lead", "Blood cadmium", "Blood mercury")),
         term = ifelse(grepl("per SD", term), "Per SD", term),
         term = factor(term, levels = c("Per SD", "Q2 vs Q1", "Q3 vs Q1", "Q4 vs Q1", "P trend")))
p <- ggplot(pd, aes(x = OR, y = term)) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.2, color = "#2C7FB8", linewidth = .6) +
  geom_point(size = 2, color = "#D7301F") +
  scale_x_log10(expand = expansion(mult = c(0.08, 0.42))) +
  coord_cartesian(clip = "off") +
  facet_wrap(~label, nrow = 1, scales = "free_x") +
  labs(title = "Blood metals and stroke prevalence",
       subtitle = "Survey-weighted logistic regression, fully adjusted model; estimates with 95% CI",
       x = "Odds ratio (95% CI, log scale)", y = NULL) +
  theme_bw(base_size = 11) +
  theme(strip.background = element_rect(fill = "#EFF3F6"),
        plot.margin = margin(8, 26, 8, 8))
ggsave(file.path(OUT, "figures", "fig2_metals_forest_JoS.png"), p, width = 11, height = 4.2, dpi = 300)
cat("saved fig2\n")

# ---- Figure 4: Cox 死亡森林图（300 dpi）----
r2 <- read.csv(file.path(OUT, "cox_mortality_results.csv"))
oc_lab <- c(d_all = "All-cause mortality", d_cvd = "Cardiovascular mortality",
            d_cbv = "Cerebrovascular mortality", d_chd = "Coronary mortality")
r2 <- r2 %>% filter(model == "single") %>%
  mutate(outcome_lab = factor(oc_lab[outcome], levels = unname(oc_lab)),
         sig = P < 0.05)
p2 <- ggplot(r2, aes(x = HR, y = label, color = sig)) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.2, linewidth = .7) +
  geom_point(size = 2.4) +
  scale_color_manual(values = c(`TRUE` = "#D7301F", `FALSE` = "grey45"),
                     labels = c(`TRUE` = "P < 0.05", `FALSE` = "NS"), name = NULL) +
  facet_wrap(~outcome_lab, ncol = 2, scales = "free_x") +
  scale_x_log10(expand = expansion(mult = c(0.06, 0.5))) +
  coord_cartesian(clip = "off") +
  labs(title = "Blood metals and mortality (NDI-linked follow-up through 2019)",
       subtitle = "Survey-weighted Cox models, per 1 SD increment, fully adjusted; n = 26,208",
       x = "Hazard ratio (95% CI, log scale)", y = NULL) +
  theme_bw(base_size = 11) +
  theme(strip.background = element_rect(fill = "#EFF3F6"),
        plot.margin = margin(8, 30, 8, 8))
ggsave(file.path(OUT, "figures", "fig4_cox_forest_JoS.png"), p2, width = 11, height = 6, dpi = 300)
cat("saved fig4\n")
