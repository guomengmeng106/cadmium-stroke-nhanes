# Cox 死亡结局森林图
library(arrow); library(dplyr); library(ggplot2)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

r <- read.csv(file.path(OUT, "cox_mortality_results.csv"), fileEncoding = "UTF-8")

oc_lab <- c(d_all = "All-cause mortality", d_cvd = "CVD mortality",
            d_cbv = "Cerebrovascular mortality", d_chd = "Coronary heart disease mortality")
r <- r %>% mutate(outcome_lab = oc_lab[outcome],
                  outcome_lab = factor(outcome_lab, levels = unname(oc_lab)),
                  sig = P < 0.05)
pd <- r %>% filter(model == "single")

p <- ggplot(pd, aes(x = HR, y = label, color = sig)) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.22, linewidth = .7) +
  geom_point(size = 2.6) +
  geom_text(aes(label = HR_CI), hjust = 0, size = 3, nudge_x = 0.03, show.legend = FALSE) +
  scale_color_manual(values = c(`TRUE` = "#D7301F", `FALSE` = "grey45"),
                     labels = c(`TRUE` = "P < 0.05", `FALSE` = "NS"), name = NULL) +
  facet_wrap(~outcome_lab, ncol = 2, scales = "free_x") +
  scale_x_log10(expand = expansion(mult = c(0.05, 0.55))) +
  coord_cartesian(clip = "off") +
  labs(title = "Blood metals and mortality (NHANES 1999\u20132018 linked to NDI)",
       subtitle = "Survey-weighted Cox models, per 1 SD increment, adjusted for full covariate set",
       x = "Hazard ratio (95% CI, log scale)", y = NULL) +
  theme_bw(base_size = 11) +
  theme(strip.background = element_rect(fill = "#EFF3F6"),
        plot.margin = margin(10, 30, 10, 10))
ggsave(file.path(OUT, "figures", "forest_cox_mortality.png"), p, width = 11, height = 6, dpi = 200)
cat("saved forest_cox_mortality.png\n")
