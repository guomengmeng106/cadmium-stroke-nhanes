# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""JoS Figure 1: 研究流程图"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(8.2, 8.8), dpi=300)
ax.set_xlim(0, 10.8); ax.set_ylim(0, 12.4); ax.axis("off")

boxes = [
    ("Merged records in Harmonized NHANES 1988\u20132018\n(n = 135,310)", 11.3),
    ("Continuous cycles 1999\u20132018\n(n = 101,316)", 9.9),
    ("Adults aged \u226520 years\n(n = 55,081)", 8.5),
    ("Non-pregnant participants\n(n = 53,540)", 7.1),
    ("Valid self-reported stroke status\n(n = 53,459; 2,196 strokes)", 5.7),
]
for text, y in boxes:
    ax.add_patch(FancyBboxPatch((1.6, y - 0.52), 6.8, 1.04,
                 boxstyle="round,pad=0.06", fc="#EFF3F6", ec="#5B7C99", lw=1.2))
    ax.text(5.0, y, text, ha="center", va="center", fontsize=10.5)

subs = [
    ("Metals analysis\nLead & cadmium n = 31,275\nMercury n = 26,232", 3.6, 0.75),
    ("Inflammatory indices\nn = 35,470", 3.6, 3.95),
    ("TyG indices (fasting)\nn = 4,701", 3.6, 7.15),
]
for text, y, x in subs:
    ax.add_patch(FancyBboxPatch((x - 0.15, y - 0.62), 2.85, 1.24,
                 boxstyle="round,pad=0.06", fc="#FDF6EC", ec="#C08A3E", lw=1.1))
    ax.text(x + 1.275, y, text, ha="center", va="center", fontsize=9.5)

# 主链箭头
for y0, y1 in [(10.78, 10.42), (9.38, 9.02), (7.98, 7.62), (6.58, 6.22)]:
    ax.add_patch(FancyArrowPatch((5.0, y0), (5.0, y1), arrowstyle="-|>",
                 mutation_scale=16, lw=1.4, color="#5B7C99"))
# 分支箭头
for x in [2.03, 5.23, 8.43]:
    ax.add_patch(FancyArrowPatch((5.0, 5.18), (x, 4.35), arrowstyle="-|>",
                 mutation_scale=14, lw=1.2, color="#C08A3E",
                 connectionstyle="arc3,rad=0.0"))

ax.text(5.4, 12.1, "Study population selection", ha="center", fontsize=12.5, fontweight="bold")
ax.text(5.0, 0.35, "TyG, triglyceride-glucose; NHANES, National Health and Nutrition Examination Survey.",
        ha="center", fontsize=8.5, style="italic")
plt.tight_layout()
plt.savefig(OUT, dpi=300, bbox_inches="tight", facecolor="white")
print("saved", OUT)
