# 画 JoS Figure 3：血铅 + 血镉 RCS 双面板（加权，Model 2 协变量）
library(arrow); library(dplyr); library(survey); library(ggplot2); library(patchwork)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(survey.lonely.psu = "adjust")
df <- read_parquet(file.path(OUT, "analysis_clean2.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR, pir = INDFMPIR, bmi = BMXBMI,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")

rcs_curve <- function(ev, label, unit) {
  req <- c(ev, "wt_pb", "stroke", COV2, "SDMVPSU", "SDMVSTRA")
  dd <- df %>% filter(if_all(all_of(req), ~ !is.na(.x))) %>% filter(wt_pb > 0)
  bb <- splines::ns(dd[[ev]], df = 3)
  kn <- attr(bb, "knots"); bk <- attr(bb, "Boundary.knots")
  dd$ns1 <- bb[, 1]; dd$ns2 <- bb[, 2]; dd$ns3 <- bb[, 3]
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = dd, nest = TRUE)
  m <- svyglm(stroke ~ ns1 + ns2 + ns3 + age + female + race + educ + pir + bmi +
                smoke + diabetes + hyperten + alcohol, design = des, family = quasibinomial())
  grid <- seq(quantile(dd[[ev]], .01), quantile(dd[[ev]], .99), length.out = 200)
  ref <- median(dd[[ev]])
  nb <- splines::ns(grid, knots = kn, Boundary.knots = bk)
  rb <- splines::ns(ref, knots = kn, Boundary.knots = bk)
  dif <- sweep(nb, 2, as.vector(rb), "-")
  idx <- c("ns1", "ns2", "ns3")
  cf <- coef(m); nsb <- cf[idx]
  V <- vcov(m)[idx, idx]
  lp <- as.vector(dif %*% nsb)
  se <- sqrt(pmax(rowSums((dif %*% V) * dif), 0))
  data.frame(x = grid, OR = exp(lp), lo = exp(lp - 1.96 * se), hi = exp(lp + 1.96 * se),
             metal = label, unit = unit)
}

pd <- rcs_curve("LBXBPB", "Blood lead", "\u00b5g/dL")
cd <- rcs_curve("LBXBCD", "Blood cadmium", "\u00b5g/L")
d <- bind_rows(pd, cd)

# 按金属分面：x 轴各自尺度
p1 <- ggplot(subset(d, metal == "Blood lead"), aes(x, OR)) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = 0.18, fill = "#2C7FB8") +
  geom_line(color = "#D7301F", linewidth = 1) +
  geom_hline(yintercept = 1, linetype = 2, color = "grey55") +
  coord_cartesian(ylim = c(0, 3)) +
  labs(title = "A. Blood lead (P for nonlinearity = 0.049)",
       x = "Blood lead (\u00b5g/dL)", y = "OR (95% CI)") + theme_bw(base_size = 12)
p2 <- ggplot(subset(d, metal == "Blood cadmium"), aes(x, OR)) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = 0.18, fill = "#2C7FB8") +
  geom_line(color = "#D7301F", linewidth = 1) +
  geom_hline(yintercept = 1, linetype = 2, color = "grey55") +
  coord_cartesian(ylim = c(0, 3)) +
  labs(title = "B. Blood cadmium (P for nonlinearity = 0.004)",
       x = "Blood cadmium (\u00b5g/L)", y = "OR (95% CI)") + theme_bw(base_size = 12)

g <- p1 + p2 + plot_annotation(
  title = "Restricted cubic splines for metals and stroke prevalence (weighted, Model 2)",
  theme = theme(plot.title = element_text(size = 13, face = "bold")))
ggsave(file.path(OUT, "figures", "fig3_rcs_pb_cd_JoS.png"), g, width = 10.5, height = 4.8, dpi = 300)
cat("saved fig3_rcs_pb_cd_JoS.png\n")
