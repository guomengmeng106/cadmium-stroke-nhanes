# NHANES 1999-2018: 重金属的前瞻性死亡结局（NDI 链接）+ 汞-鱼敏感性分析
library(arrow); library(dplyr); library(survey); library(survival)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(survey.lonely.psu = "adjust")
df <- read_parquet(file.path(OUT, "analysis_clean2.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  pir = INDFMPIR, bmi = BMXBMI,
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")

METALS <- c("LBXBPB", "LBXBCD", "LBXTHG")
LAB <- c(LBXBPB = "Blood lead", LBXBCD = "Blood cadmium", LBXTHG = "Blood mercury")

# ============ Cox 样本 ============
mk <- function(vars, needMetals = TRUE) {
  req <- c(vars, "wt_pb", "fuyr_exm", "SDMVPSU", "SDMVSTRA", COV2)
  if (needMetals) req <- c(req, METALS)
  dd <- df %>% filter(mort_elig == 1, fuyr_exm > 0, wt_pb > 0)
  dd <- dd %>% filter(if_all(all_of(req), ~ !is.na(.x)))
  for (v in METALS) {
    sdx <- sd(dd[[v]], na.rm = TRUE)
    dd[[paste0(v, "_sd")]] <- dd[[v]] / sdx
    attr(dd, paste0("sd_", v)) <- sdx
  }
  dd
}

cox_run <- function(dd, vars, outcome) {
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = dd, nest = TRUE)
  f <- as.formula(paste0("Surv(fuyr_exm, ", outcome, ") ~ ", paste(vars, collapse = " + "),
                         " + ", paste(COV2, collapse = " + ")))
  m <- suppressWarnings(svycoxph(f, design = des))
  s <- summary(m)$coefficients          # 列: coef, exp(coef), se(coef), robust se, z, Pr(>|z|)
  out <- do.call(rbind, lapply(vars, function(v) {
    b <- s[v, "coef"]; se <- s[v, "robust se"]; p <- s[v, "Pr(>|z|)"]
    data.frame(exposure = v, label = LAB[[sub("_sd$", "", v)]],
               HR = exp(b), lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se), P = p)
  }))
  out$outcome <- outcome
  out$n <- nrow(dd); out$n_event <- sum(dd[[outcome]] == 1)
  out
}

cat("### Cox: 单个金属模型 ###\n")
res <- list()
dd <- mk("d_all")
cat("Cox 分析样本 n =", nrow(dd), "; 全因死亡 =", sum(dd$d_all == 1),
    "; CVD 死亡 =", sum(dd$d_cvd == 1), "; 脑血管死亡 =", sum(dd$d_cbv == 1), "\n")
for (oc in c("d_all", "d_cvd", "d_cbv", "d_chd")) {
  for (v in paste0(METALS, "_sd")) {
    r <- cox_run(dd, v, oc); r$model <- "single"
    res[[paste(oc, v)]] <- r
  }
}

cat("### Cox: 三金属联合模型 ###\n")
for (oc in c("d_all", "d_cvd", "d_cbv", "d_chd")) {
  vs <- paste0(METALS, "_sd")
  dd2 <- dd
  # 联合模型剔除汞缺失者（汞子样本更小）
  dd2 <- dd2 %>% filter(!is.na(LBXTHG))
  r <- cox_run(dd2, vs, oc); r$model <- "joint"
  res[[paste0(oc, "_joint")]] <- r
}

RES <- bind_rows(res)
fmt <- function(r) sprintf("%.2f (%.2f-%.2f)%s", r$HR, r$lo, r$hi,
  ifelse(r$P < .001, "***", ifelse(r$P < .01, "**", ifelse(r$P < .05, "*", ""))))
RES$HR_CI <- fmt(RES)
write.csv(RES, file.path(OUT, "cox_mortality_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")

cat("\n=== Cox 结果摘要 ===\n")
for (oc in unique(RES$outcome)) {
  cat("\n--", oc, "--\n")
  sub <- RES %>% filter(outcome == oc)
  print(sub %>% transmute(model, label, HR_CI, P = round(P, 4), n, n_event))
}

# ============ 汞-鱼敏感性（横断面 logistic） ============
cat("\n\n########## 汞-鱼敏感性分析 ##########\n")
dds <- df %>% filter(!is.na(LBXTHG), !is.na(DRXT_PF_SEAFD_HI), wt_pb > 0) %>%
  filter(if_all(all_of(c("stroke", COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)))
sdHg <- sd(dds$LBXTHG, na.rm = TRUE); sdsf <- sd(dds$DRXT_PF_SEAFD_HI, na.rm = TRUE)
dds$Hg_sd <- dds$LBXTHG / sdHg
dds$sf_sd <- dds$DRXT_PF_SEAFD_HI / sdsf
cat("样本 n =", nrow(dds), "| 卒中 =", sum(dds$stroke == 1),
    "| Hg SD =", round(sdHg, 2), "| seafood_hi SD =", round(sdsf, 3), "\n")

des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = dds, nest = TRUE)
grab <- function(m, term) {
  s <- summary(m)$coefficients
  b <- s[term, "Estimate"]; se <- s[term, "Std. Error"]
  data.frame(term = term, OR = exp(b), lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se),
             P = s[term, "Pr(>|t|)"])
}
base_ex <- function() as.formula(paste("stroke ~", paste(c("Hg_sd", COV2), collapse = " + ")))
m1 <- svyglm(base_ex(), design = des, family = quasibinomial())
m2 <- svyglm(as.formula(paste("stroke ~ Hg_sd + sf_sd +", paste(COV2, collapse = " + "))),
             design = des, family = quasibinomial())
m3 <- svyglm(as.formula(paste("stroke ~ Hg_sd + sf_sd + DRXTP205 + DRXTP226 +",
                              paste(COV2, collapse = " + "))),
             design = des, family = quasibinomial())

tab <- rbind(
  cbind(Model = "A: Hg only (Model 2)", grab(m1, "Hg_sd")),
  cbind(Model = "B: + seafood high n-3 (oz eq/SD)", grab(m2, "Hg_sd")),
  cbind(Model = "C: + seafood + dietary EPA + DHA", grab(m3, "Hg_sd"))
)
s1 <- grab(m1, "Hg_sd"); s2 <- grab(m2, "Hg_sd"); s3 <- grab(m3, "Hg_sd")
att <- round(100 * (1 - log(s1$OR) / c(log(s1$OR), log(s2$OR), log(s3$OR))), 1)
tab$attenuation_pct <- c(0, att[2], att[3])
tab$OR_CI <- sprintf("%.2f (%.2f-%.2f)%s", tab$OR, tab$lo, tab$hi,
  ifelse(tab$P < .05, "*", ""))
print(tab %>% select(Model, term, OR_CI, P, attenuation_pct))

# 海鲜 vs 卒中、Hg 与海鲜的相关
cat("\n海鲜摄入本身与卒中的关联：\n")
print(grab(m2, "sf_sd"))
cat("\n血汞与海鲜摄入的相关 (weighted Pearson):\n")
cc <- svycor <- NULL
w <- weights(des)
ok <- !is.na(dds$LBXTHG) & !is.na(dds$DRXT_PF_SEAFD_HI)
cat("  r =", round(cov.wt(dds[ok, c("LBXTHG", "DRXT_PF_SEAFD_HI")], wt = dds$wt_pb[ok], cor = TRUE)$cor[1, 2], 3), "\n")

# Hg 按海鲜摄入四分位分层
cat("\n血汞 OR 按海鲜(高n-3)摄入四分位分层：\n")
dds$sfQ <- cut(dds$DRXT_PF_SEAFD_HI,
               breaks = unique(quantile(dds$DRXT_PF_SEAFD_HI, c(0, .25, .5, .75, 1), na.rm = TRUE)),
               include.lowest = TRUE, labels = c("Q1", "Q2", "Q3", "Q4"))
for (q in levels(dds$sfQ)) {
  sub <- dds %>% filter(sfQ == q)
  sub$Hg_sd <- sub$LBXTHG / sd(sub$LBXTHG, na.rm = TRUE)
  d2 <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = sub, nest = TRUE)
  mm <- try(svyglm(as.formula(paste("stroke ~ Hg_sd +", paste(COV2, collapse = " + "))),
                   design = d2, family = quasibinomial()), silent = TRUE)
  if (!inherits(mm, "try-error")) {
    r <- grab(mm, "Hg_sd")
    cat(sprintf("  %s (n=%d, strokes=%d): OR = %.2f (%.2f-%.2f)  P=%.3f\n",
                q, nrow(sub), sum(sub$stroke == 1), r$OR, r$lo, r$hi, r$P))
  } else cat("  ", q, "模型失败\n")
}

write.csv(tab, file.path(OUT, "mercury_fish_sensitivity.csv"), row.names = FALSE, fileEncoding = "UTF-8")
cat("\nDONE\n")
