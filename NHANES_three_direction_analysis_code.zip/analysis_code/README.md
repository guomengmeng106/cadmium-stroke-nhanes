# NHANES 1999–2018 三方向与卒中关联分析 — 可复现代码包

本代码包完整复现「**重金属 / 炎症复合指标 / TyG 系列指数**」三条暴露通路与美国成人卒中患病的关联分析，
采用 NHANES 复杂抽样设计（分层、聚类、加权）下的 survey 加权 logistic 回归、限制性立方样条（RCS）与亚组分析。

对应稿件：*Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999–2018*
（投稿 *Journal of Stroke*）。

---

## 1. 环境依赖

**Python**（3.12+，已验证 3.13.12）
```bash
pip install polars pyarrow pandas numpy matplotlib python-docx
```

**R**（4.4+，已验证 4.6.0）
```r
install.packages(c("survey", "arrow", "dplyr", "ggplot2", "broom",
                   "survival", "rms", "qgcomp", "gWQS"))
```

数据源：**Harmonized NHANES 1988–2018** 清洗后 CSV（`SEQN_new` 为跨周期统一主键）。

---

## 2. 路径配置（迁移到其他机器只需设环境变量）

所有脚本的路径均已参数化，**默认值为本机的原始路径**；换机器时用环境变量覆盖即可，无需改代码：

| 环境变量 | 含义 | 默认值 |
|---|---|---|
| `NHANES_OUT` | 分析输出目录 | `.../outputs/nhanes_analysis` |
| `NHANES_DATA` | NHANES 清洗后 CSV 目录 | `D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗` |
| `NHANES_RDATA` | 原始 RData（仅 `00` 提取字典用） | `D:/数据库/NHANME/w - nhanes_1988_2018.RData` |

```bash
# Windows (Git Bash)
export NHANES_OUT="D:/my_project/output"
export NHANES_DATA="E:/NHANES/clean"

# Linux / macOS
export NHANES_OUT="/data/nhanes_out"
export NHANES_DATA="/data/nhanes_clean"
```

---

## 3. 目录结构与执行顺序

### Stage A — 三方向核心分析（本次任务的主链路）

| 序号 | 脚本 | 作用 | 主要产出 |
|---|---|---|---|
| 00 | `00_extract_dictionary.R` | 从原始 RData 导出变量字典与分类变量释义 | `df_dictionary.csv`、`df_levels_categorical_variables.csv` |
| 01 | `01_build_dataset.py` | 从 5 个模块 CSV 按需提取列、按 `SEQN_new` 左连接 | `analysis_base.parquet` |
| 02 | `02_clean_analysis.py` | 样本筛选 + 特殊缺失码清洗 + 派生暴露与权重 | `analysis_clean.parquet` |
| 03 | **`03_analyze_survey.R`** | **核心**：三方向 × Crude/Model 1/Model 2 加权 logistic + 四分位 + 趋势检验 | `or_results.csv`、`figures/forest_*.png` |
| 04 | `04_rcs_nonlinearity.R` | RCS 曲线与非线性检验（联合 Wald 检验 ns1–ns3） | `figures/rcs_*.png` |
| 05 | `05_table1_subgroup.R` | 加权基线特征表（Table 1）+ 血镉亚组分析 | `table1.csv`、`subgroup_cadmium.csv` |
| 06 | `06_extra_stats.R` | 加权患病率、暴露分布中位数/IQR、RCS 非线性 P 值汇总 | `descriptives.csv`、`rcs_pvalues.csv` |
| 07 | `07_redraw_forest.R` | 统一标签后重绘森林图（修掉跨面板标签泄漏） | `figures/forest_*.png` |

### Stage B — 扩展分析（死亡随访 / 混合暴露 / 敏感性）

| 序号 | 脚本 | 作用 | 主要产出 |
|---|---|---|---|
| 10 | `10_build_dataset2.py` | 追加 NDI 死亡链接表与膳食海鲜/EPA/DHA（膳食表按人两日均值聚合） | `analysis_base2.parquet` |
| 11 | `11_clean_dataset2.py` | 生成死亡标志、随访人年、eGFR | `analysis_clean2.parquet` |
| 12 | `12_cox_mortality.R` | 加权 Cox：全因/心血管/冠心病/脑血管死亡 + 汞-鱼敏感性 | `cox_mortality_results.csv`、`mercury_fish_sensitivity.csv` |
| 13 | `13_mixture_wqs.R` | 自实现的 survey-weighted quantile g-computation（混合效应与金属权重） | `mixture_*.csv`、`figures/mixture_weights_svy_qgcomp.png` |
| 14 | `14_reviewer_sensitivity.R` | 审稿补充：Cox+seafood、eGFR 调整敏感性 | `reviewer_sensitivity_analyses.csv` |
| — | `figures/plot_cox.R`、`plot_flow.py`、`plot_jos_figs.R`、`plot_jos_forests.R` | 投稿用 300 dpi 图（流程图、森林图、RCS 双面板） | `figures/fig*.png` |

### Stage C — 稿件与投稿包生成

| 脚本 | 作用 |
|---|---|
| `manuscript/md2docx.py` | Markdown → docx（真上标引用、仅横线表格、双倍行距） |
| `manuscript/build_jos_manuscript.py` | 按 *Journal of Stroke* 体例重组主文档（结构式摘要、五段正文、Vancouver 文献） |
| `manuscript/build_jos_package.py` | 生成标题页 / Cover Letter / 补充材料 |
| `manuscript/build_review_report.py` | 生成模拟审稿报告 |

---

## 4. 一键运行

```bash
# Stage A（三方向核心，约 10–15 分钟）
bash run_all.sh A          # Windows: run_all.bat A

# Stage B（需先完成 A，另需 10–20 分钟）
bash run_all.sh B

# 全部
bash run_all.sh ALL
```

---

## 5. 关键方法学设计

**样本筛选**：`SDDSRVYR >= 1`（1999–2018 连续周期）→ 年龄 ≥ 20 岁 → 非妊娠 → `MCQ160F ∈ {1,2}`（卒中自报明确）。
最终 **53,459 人，卒中 2,196 例**。

**结局**：`MCQ160F = 1`（自报卒中）。该 harmonized 数据集**无缺血/出血亚型分型**。

**三类暴露与各自权重**（权重均按 10 周期合并，即 `/10`）：

| 方向 | 暴露 | 权重变量 | 分析样本 | 卒中例数 |
|---|---|---|---|---|
| 重金属 | 血铅 `LBXBPB`、血镉 `LBXBCD`、血汞 `LBXTHG` | `wt_pb` (`WT_LBXBPB`) | 31,275（汞 26,232） | 1,127 |
| 炎症 | `SII`、`SIRI`、`NLR`、`PLR`、`MAR` | `wt_mec` (`WTMEC2YR`) | 35,470 | 1,270 |
| TyG | `TyG`、`TyG_BMI`、`TyG_WC`、`TyG_WHtR` | `wt_tyg` (`WTSAF2YR`) | 4,701 | 148 |

**暴露公式**
- `TyG = ln(0.5 × TG × 空腹血糖)`；`TyG_BMI = TyG × BMI`；`TyG_WC = TyG × 腰围`；`TyG_WHtR = TyG × 腰围 / 身高`
- `SII = 血小板 × 中性粒 / 淋巴`；`SIRI = 中性粒 × 单核 / 淋巴`；`NLR = 中性粒 / 淋巴`；`PLR = 血小板 / 淋巴`；`MAR = 单核 / 白蛋白`

**协变量集**
- Model 1：年龄、性别、种族
- **Model 2（全调整）**：Model 1 + 教育、贫困指数(PIR)、BMI、吸烟、糖尿病、高血压、饮酒

**吸烟定义（重要）**：该 harmonized 数据集**缺失跨周期连续的 SMQ 问卷变量**，因此改用**血清可替宁客观定义**：
`<1 ng/mL = 非吸烟`、`1–10 = 被动/既往`、`≥10 = 当前吸烟`。方法学上比自报更稳健。

**抽样设计**：`svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_*, nest = TRUE)`，
`svyglm(family = quasibinomial())`，`survey.lonely.psu = "adjust"`。

---

## 6. 核心结果对照（Model 2 全调整）

复现后请核对以下数值（`or_results.csv`，`model == "Model 2"`）：

| 方向 | 暴露 | per SD OR (95% CI) | P | Q4 vs Q1 OR (95% CI) | P |
|---|---|---|---|---|---|
| 重金属 | **血镉** | **1.12 (1.05–1.19)** | 0.0006 | **1.86 (1.31–2.64)** | 0.0007 |
| 重金属 | 血铅 | 1.08 (1.01–1.15) | 0.017 | 1.33 (0.96–1.85) | 0.093 |
| 重金属 | 血汞 | **0.80 (0.67–0.95)** | 0.014 | **0.71 (0.52–0.96)** | 0.031 |
| 炎症 | NLR | 1.07 (1.01–1.13) | 0.014 | 1.18 (0.93–1.48) | 0.170 |
| 炎症 | SIRI | 1.06 (1.01–1.12) | 0.027 | 1.20 (0.95–1.53) | 0.135 |
| 炎症 | SII | 1.06 (1.01–1.12) | 0.033 | 1.15 (0.90–1.47) | 0.253 |
| 炎症 | PLR / MAR | 1.04 / 1.06 | NS | — | NS |
| TyG | TyG | 1.18 (0.93–1.49) | 0.184 | 2.08 (0.87–5.00) | 0.113 |
| TyG | TyG_BMI/WC/WHtR | 1.09–1.61 | NS | — | NS |

**结论要点**：镉呈强剂量反应且非线性显著（RCS P=0.004）；汞反向（"汞-鱼悖论"，后续敏感性分析显示调整海鲜/n-3 后仅衰减 3.6–8.3%）；
炎症指标仅弱独立正相关；TyG 系列在全调整后全部失去显著性（空腹子样本仅 148 例，效能不足）。

---

## 7. 复现验证记录

本代码包已在临时输出目录完整跑通 Stage A（`01 → 02 → 03`），并逐字段比对：

- `or_results.csv` **84 行与原始结果完全一致**（`identical = TRUE`）
- 血镉 Q4 vs Q1：OR = 1.8619 (1.3112–2.6439)，P = 0.00072
- 样本量：53,459（与稿件一致）

---

## 8. 已知坑（改动代码时务必注意）

1. **RCS 必须用训练数据的 knots 在网格上重建 basis**。早期版本在预测网格上直接调用 `splines::ns()`，
   因 knots 不同导致 basis 维度不匹配而报错，且会画出**形态错误的曲线**（如铅的假性钟形下跌）。
   正确实现见 `04_rcs_nonlinearity.R`（`splines::ns(grid, knots = kn, Boundary.knots = bk)`）。
   `03` 脚本内的旧 RCS 段已移除并指向 `04`。
2. **`svycoxph` 的系数矩阵列名**是 `coef / exp(coef) / robust se / Pr(>|z|)`，**不是** `Estimate / Std. Error`。
   且公式中的变量必须全部存在于 `design$variables` 中，否则 `all.vars` 校验报错。
3. **膳食表是按「人 × 召回日」展开的**（324,374 行 > 135,310 人），直接 join 会放大数据。
   必须先按 `SEQN_new` 对两天取均值再合并（`10_build_dataset2.py` 已处理）。
4. **森林图 facet 的 `term` 因子必须统一标签**（如统一为 "Per SD"），否则跨面板会泄漏空行标签。
5. **亚组分析需设 `options(survey.lonely.psu = "adjust")`**，否则某些分层只剩 1 个 PSU 时报错。
6. `gWQS` 包在本环境返回对象不稳定（"incorrect number of dimensions"）；`13` 中改用**自实现的
   survey-weighted qgcomp**（四分位得分进 `svyglm`，psi = Σβ，Delta 法方差），数学上等价且更好地保留复杂抽样方差结构。

---

## 9. 许可证与引用

数据使用遵循 NHANES 数据使用协议。若使用本代码，请引用相应稿件。
