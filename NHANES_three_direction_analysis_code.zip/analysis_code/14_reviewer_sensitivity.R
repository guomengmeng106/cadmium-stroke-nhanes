# 审稿补充分析：M6 汞-脑血管死亡×seafood；M7 镉模型×eGFR
library(arrow); library(dplyr); library(survey); library(survival)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(survey.lonely.psu = "adjust")
df <- read_parquet(file.path(OUT, "analysis_clean2.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR, pir = INDFMPIR, bmi = BMXBMI,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")

grabcox <- function(m, term, label) {
  s <- summary(m)$coefficients
  b <- s[term, "coef"]; se <- s[term, "robust se"]
  data.frame(label = label, HR = exp(b), lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se),
             P = s[term, "Pr(>|z|)"])
}
grablogit <- function(m, term, label) {
  s <- summary(m)$coefficients
  b <- s[term, "Estimate"]; se <- s[term, "Std. Error"]
  data.frame(label = label, OR = exp(b), lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se),
             P = s[term, "Pr(>|t|)"])
}
fmt <- function(r, e = "OR") sprintf("%s = %.2f (%.2f-%.2f), P=%.3g", e, r[[e]], r$lo, r$hi, r$P)

cat("########## M6: 汞-脑血管死亡 × seafood（Cox）##########\n")
d6 <- df %>% filter(mort_elig == 1, fuyr_exm > 0, wt_pb > 0,
                    !is.na(LBXTHG), !is.na(DRXT_PF_SEAFD_HI), !is.na(VNEGFR)) %>%
  filter(if_all(all_of(c(COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)))
d6$Hg_sd <- d6$LBXTHG / sd(d6$LBXTHG)
d6$sf_sd <- d6$DRXT_PF_SEAFD_HI / sd(d6$DRXT_PF_SEAFD_HI)
cat("M6 样本 n =", nrow(d6), "| 脑血管死亡 =", sum(d6$d_cbv == 1), "\n")
des6 <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = d6, nest = TRUE)
m6a <- svycoxph(Surv(fuyr_exm, d_cbv) ~ Hg_sd + age + female + race + educ + pir + bmi +
                  smoke + diabetes + hyperten + alcohol, design = des6)
m6b <- svycoxph(Surv(fuyr_exm, d_cbv) ~ Hg_sd + sf_sd + age + female + race + educ + pir + bmi +
                  smoke + diabetes + hyperten + alcohol, design = des6)
m6c <- svycoxph(Surv(fuyr_exm, d_cbv) ~ Hg_sd + sf_sd + VNEGFR + age + female + race + educ + pir + bmi +
                  smoke + diabetes + hyperten + alcohol, design = des6)
r6a <- grabcox(m6a, "Hg_sd", "Hg only"); r6b <- grabcox(m6b, "Hg_sd", "+ seafood"); r6c <- grabcox(m6c, "Hg_sd", "+ seafood + eGFR")
print(r6a); print(r6b); print(r6c)
att6 <- round(100 * (1 - log(r6b$HR) / log(r6a$HR)), 1)
att6c <- round(100 * (1 - log(r6c$HR) / log(r6a$HR)), 1)
cat(sprintf("attenuation vs base: +seafood %.1f%%, +seafood+eGFR %.1f%%\n", att6, att6c))

cat("\n########## M7a: 镉-卒中 logistic × eGFR ##########\n")
d7 <- df %>% filter(wt_pb > 0, !is.na(LBXBCD), !is.na(VNEGFR)) %>%
  filter(if_all(all_of(c("stroke", COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)))
d7$Cd_sd <- d7$LBXBCD / sd(d7$LBXBCD)
cat("M7a 样本 n =", nrow(d7), "| 卒中 =", sum(d7$stroke == 1), "\n")
des7 <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = d7, nest = TRUE)
m7a <- svyglm(stroke ~ Cd_sd + age + female + race + educ + pir + bmi + smoke +
                diabetes + hyperten + alcohol, design = des7, family = quasibinomial())
m7b <- svyglm(stroke ~ Cd_sd + VNEGFR + age + female + race + educ + pir + bmi + smoke +
                diabetes + hyperten + alcohol, design = des7, family = quasibinomial())
r7a <- grablogit(m7a, "Cd_sd", "Cd only"); r7b <- grablogit(m7b, "Cd_sd", "+ eGFR")
print(r7a); print(r7b)
cat(sprintf("Cd-卒中 attenuation: %.1f%%\n", round(100 * (1 - log(r7b$OR) / log(r7a$OR)), 1)))
r7g <- grablogit(m7b, "VNEGFR", "eGFR coef")
cat("eGFR 本身:", fmt(r7g), "\n")

cat("\n########## M7b: 镉-全因死亡 Cox × eGFR ##########\n")
d8 <- df %>% filter(mort_elig == 1, fuyr_exm > 0, wt_pb > 0, !is.na(LBXBCD), !is.na(VNEGFR)) %>%
  filter(if_all(all_of(c(COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)))
d8$Cd_sd <- d8$LBXBCD / sd(d8$LBXBCD)
cat("M7b 样本 n =", nrow(d8), "| 死亡 =", sum(d8$d_all == 1), "\n")
des8 <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = d8, nest = TRUE)
m8a <- svycoxph(Surv(fuyr_exm, d_all) ~ Cd_sd + age + female + race + educ + pir + bmi +
                  smoke + diabetes + hyperten + alcohol, design = des8)
m8b <- svycoxph(Surv(fuyr_exm, d_all) ~ Cd_sd + VNEGFR + age + female + race + educ + pir + bmi +
                  smoke + diabetes + hyperten + alcohol, design = des8)
r8a <- grabcox(m8a, "Cd_sd", "Cd only"); r8b <- grabcox(m8b, "Cd_sd", "+ eGFR")
print(r8a); print(r8b)
cat(sprintf("Cd-全因死亡 attenuation: %.1f%%\n", round(100 * (1 - log(r8b$HR) / log(r8a$HR)), 1)))

# 汇总保存
res <- bind_rows(
  cbind(analysis = "M6_cbv_Hg", r6a), cbind(analysis = "M6_cbv_Hg_seafood", r6b),
  cbind(analysis = "M6_cbv_Hg_seafood_egfr", r6c),
  cbind(analysis = "M7a_stroke_Cd", r7a), cbind(analysis = "M7a_stroke_Cd_egfr", r7b),
  cbind(analysis = "M7b_mort_Cd", r8a), cbind(analysis = "M7b_mort_Cd_egfr", r8b)
)
write.csv(res, file.path(OUT, "reviewer_sensitivity_analyses.csv"), row.names = FALSE, fileEncoding = "UTF-8")
cat("\nsaved reviewer_sensitivity_analyses.csv\nDONE\n")
