#!/usr/bin/env bash
# 一键复现 NHANES 三方向分析
# 用法:  bash run_all.sh A | B | C | ALL
# 前置:  设置环境变量 NHANES_OUT / NHANES_DATA（未设置则用脚本内默认值）
set -euo pipefail

PY="${PY:-python}"
RS="${RS:-Rscript}"
STAGE="${1:-A}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

run_py() { echo "---- PY  $1"; "$PY" "$HERE/$1"; }
run_r()  { echo "---- R   $1"; "$RS" "$HERE/$1"; }

stage_a() {
  echo "=========== Stage A: 三方向核心分析 ==========="
  run_r  00_extract_dictionary.R
  run_py 01_build_dataset.py
  run_py 02_clean_analysis.py
  run_r  03_analyze_survey.R
  run_r  04_rcs_nonlinearity.R
  run_r  05_table1_subgroup.R
  run_r  06_extra_stats.R
  run_r  07_redraw_forest.R
  echo "=========== Stage A 完成 ==========="
}

stage_b() {
  echo "=========== Stage B: 扩展分析 ==========="
  run_py 10_build_dataset2.py
  run_py 11_clean_dataset2.py
  run_r  12_cox_mortality.R
  run_r  13_mixture_wqs.R
  run_r  14_reviewer_sensitivity.R
  run_r  figures/plot_cox.R
  run_py figures/plot_flow.py
  run_r  figures/plot_jos_figs.R
  run_r  figures/plot_jos_forests.R
  echo "=========== Stage B 完成 ==========="
}

stage_c() {
  echo "=========== Stage C: 稿件与投稿包 ==========="
  run_py manuscript/build_jos_manuscript.py
  run_py manuscript/build_jos_package.py
  run_py manuscript/build_review_report.py
  echo "=========== Stage C 完成 ==========="
}

case "$STAGE" in
  A|a)   stage_a ;;
  B|b)   stage_b ;;
  C|c)   stage_c ;;
  ALL|all) stage_a; stage_b; stage_c ;;
  *) echo "用法: bash run_all.sh A | B | C | ALL"; exit 1 ;;
esac
