# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""从 harmonized NHANES 1988-2018 各模块按需提取列并合并为分析底表"""
import polars as pl
import time

SEL = {
    "3.demographics_clean.csv": ["SEQN_new", "SDDSRVYR", "RIDAGEYR", "RIAGENDR", "RIDRETH1",
        "DMDEDUC2", "DMDMARTL", "INDFMPIR", "WTINT2YR", "WTMEC2YR",
        "SDMVPSU", "SDMVSTRA", "RIDEXPRG"],
    "7.questionnaire_clean.csv": ["SEQN_new", "MCQ160F", "MCQ160B", "MCQ160C", "MCQ160D",
        "MCQ160E", "DIQ010", "BPQ020", "HAR1", "HAR3", "ALQ101"],
    "8.response_clean.csv": ["SEQN_new", "WTSAF2YR", "LBDNENO", "LBDMONO", "LBDLYMNO",
        "LBDEONO", "LBDBANO", "LBXPLTSI", "LBXWBCSI", "LBXSAL", "LBXTR",
        "LBDLDL", "LBDHDD", "LBXTC", "LBXGLU", "LBXGH", "LBXHSCRP", "LBXCRP",
        "BMXBMI", "BMXWAIST", "BMXHT", "BPXSAR", "BPXDAR"],
    "2.chemicals_clean.csv": ["SEQN_new", "LBXBPB", "LBXBCD", "LBXTHG", "LBXCOT"],
    "1.weights_clean.csv": ["SEQN_new", "WT_LBXBPB", "WT_LBXBCD", "WT_LBXTHG"],
}

ORDER = ["3.demographics_clean.csv", "7.questionnaire_clean.csv", "8.response_clean.csv",
         "2.chemicals_clean.csv", "1.weights_clean.csv"]

dfs = {}
for fn in ORDER:
    t0 = time.time()
    lf = pl.scan_csv(f"{BASE}/{fn}", infer_schema_length=0, null_values=["NA", ""])
    have = set(lf.collect_schema().names())
    want = [c for c in SEL[fn] if c in have]
    miss = [c for c in SEL[fn] if c not in have]
    if miss:
        print(f"[WARN] {fn} missing cols: {miss}")
    df = lf.select(want).collect(streaming=True)
    # 检查主键唯一性
    n, nun = df.height, df["SEQN_new"].n_unique()
    dup = "" if n == nun else f"  [!! {n - nun} dup keys]"
    print(f"{fn}: {df.shape[0]}x{df.shape[1]}  unique_key={nun}{dup}  ({time.time()-t0:.0f}s)")
    dfs[fn] = df

base = dfs[ORDER[0]]
for fn in ORDER[1:]:
    base = base.join(dfs[fn], on="SEQN_new", how="left")
print("merged:", base.shape)
base.write_parquet(f"{OUT}/analysis_base.parquet")
print("saved analysis_base.parquet")

# SDDSRVYR 分布（确定周期编码）
print("\nSDDSRVYR distribution:")
print(base.group_by("SDDSRVYR").len().sort("SDDSRVYR"))
