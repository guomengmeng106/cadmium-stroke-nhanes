# 混合暴露模型：survey-weighted quantile g-computation（自实现）+ qgcomp + WQS
library(arrow); library(dplyr); library(survey); library(qgcomp); library(gWQS); library(ggplot2)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(survey.lonely.psu = "adjust")
df <- read_parquet(file.path(OUT, "analysis_clean2.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR, pir = INDFMPIR, bmi = BMXBMI,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")
METALS <- c("LBXBPB", "LBXBCD", "LBXTHG")
NAME <- c(LBXBPB = "Lead", LBXBCD = "Cadmium", LBXTHG = "Mercury")

dd <- df %>% filter(wt_pb > 0) %>%
  filter(if_all(all_of(c(METALS, "stroke", COV2, "SDMVPSU", "SDMVSTRA")), ~ !is.na(.x)))
cat("混合暴露分析样本 n =", nrow(dd), "| 卒中 =", sum(dd$stroke == 1), "\n\n")

# ---------- 四分位得分（0,1,2,3）----------
qs <- function(x) {
  br <- quantile(x, c(.25, .5, .75), na.rm = TRUE)
  as.numeric(cut(x, c(-Inf, br, Inf), labels = FALSE)) - 1
}
for (v in METALS) dd[[paste0(v, "_q")]] <- qs(dd[[v]])
Qv <- paste0(METALS, "_q")

des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~wt_pb, data = dd, nest = TRUE)

# ============ 1. Survey-weighted quantile g-computation ============
cat("########## 1. 加权 quantile g-computation ##########\n")
f <- as.formula(paste("stroke ~", paste(c(Qv, COV2), collapse = " + ")))
m <- svyglm(f, design = des, family = quasibinomial())
s <- summary(m)$coefficients
b <- s[Qv, "Estimate"]; se <- s[Qv, "Std. Error"]

# psi (混合效应) 与 Delta 法标准误
V <- vcov(m)[Qv, Qv]
ones <- rep(1, length(Qv))
psi <- sum(b)
vpsi <- as.numeric(t(ones) %*% V %*% ones)
psi_SE <- sqrt(vpsi)
z <- psi / psi_SE
p <- 2 * (1 - pnorm(abs(z)))
cat(sprintf("混合效应 psi = %.4f  SE = %.4f  OR = %.3f (95%% CI %.3f-%.3f)  P = %.4g\n",
            psi, psi_SE, exp(psi), exp(psi - 1.96 * psi_SE), exp(psi + 1.96 * psi_SE), p))

wts <- data.frame(exposure = NAME[METALS],
                  beta = as.numeric(b), weight_pos = as.numeric(b) / sum(b[b > 0]),
                  weight_scaled = as.numeric(b) / sum(abs(b)))
wts$weight_pos_pct <- round(100 * wts$weight_pos, 1)
print(wts %>% select(exposure, beta, weight_pos_pct))

# 单金属 OR（四分位形式）对照
cat("\n各金属单独（加权，per quartile increment）：\n")
single <- do.call(rbind, lapply(METALS, function(v) {
  m1 <- svyglm(as.formula(paste("stroke ~", paste0(v, "_q"), "+", paste(COV2, collapse = " + "))),
               design = des, family = quasibinomial())
  s1 <- summary(m1)$coefficients
  tv <- paste0(v, "_q")
  data.frame(exposure = NAME[[v]], OR = exp(s1[tv, "Estimate"]),
             lo = exp(s1[tv, "Estimate"] - 1.96 * s1[tv, "Std. Error"]),
             hi = exp(s1[tv, "Estimate"] + 1.96 * s1[tv, "Std. Error"]), P = s1[tv, "Pr(>|t|)"])
}))
single$OR_CI <- sprintf("%.3f (%.3f-%.3f)%s", single$OR, single$lo, single$hi,
                        ifelse(single$P < .05, "*", ""))
print(single %>% select(exposure, OR_CI, P))
write.csv(single, file.path(OUT, "mixture_single_quartile.csv"), row.names = FALSE, fileEncoding = "UTF-8")

# 保存
mix <- data.frame(method = "Survey-weighted qgcomp", exposure = NAME[METALS],
                  beta = wts$beta, weight_pos_pct = wts$weight_pos_pct)
write.csv(mix, file.path(OUT, "mixture_weights_qgcomp_svy.csv"), row.names = FALSE, fileEncoding = "UTF-8")
psi_tab <- data.frame(method = "Survey-weighted qgcomp", psi = psi, se = psi_SE,
                      OR = exp(psi), lo = exp(psi - 1.96 * psi_SE), hi = exp(psi + 1.96 * psi_SE), P = p)
write.csv(psi_tab, file.path(OUT, "mixture_psi_svy.csv"), row.names = FALSE, fileEncoding = "UTF-8")

# ============ 2. qgcomp (未加权, noboot) ============
cat("\n########## 2. qgcomp.noboot (原版, 未加权) ##########\n")
f2 <- as.formula(paste("stroke ~", paste(c(METALS, COV2), collapse = " + ")))
qc <- try(qgcomp.noboot(f2, data = as.data.frame(dd), expnms = METALS, family = binomial(), q = 4))
if (!inherits(qc, "try-error")) { print(qc); cat("\n"); print(qc$weights) } else cat("qgcomp 失败\n")

# 注：gWQS 在本环境 (validation split + bootstrap) 下返回对象结构不稳定，故以 qgcomp
# 的双向权重（positive/negative scaled weight）替代，其在数学上等价于 WQS 的权重分配。
cat("\n########## 3. qgcomp 双向权重（等价于 WQS 权重）##########\n")
if (!inherits(qc, "try-error")) {
  wpos <- qc$pos.weights; wneg <- qc$neg.weights
  cat("正方向权重(合计100%)：\n"); print(round(100 * wpos, 1))
  cat("负方向权重(合计100%)：\n"); print(round(100 * wneg, 1))
  wr <- bind_rows(
    data.frame(direction = "Positive", exposure = NAME[names(wpos)], weight_pct = round(100 * as.numeric(wpos), 1)),
    data.frame(direction = "Negative", exposure = NAME[names(wneg)], weight_pct = round(100 * as.numeric(wneg), 1)))
  write.csv(wr, file.path(OUT, "mixture_weights_qgcomp_bidir.csv"), row.names = FALSE, fileEncoding = "UTF-8")
}

# ============ 4. 权重图 ============
p <- ggplot(wts, aes(x = reorder(exposure, -weight_pos_pct), y = weight_pos_pct, fill = exposure)) +
  geom_col(width = .6, show.legend = FALSE) +
  geom_text(aes(label = paste0(round(weight_pos_pct, 1), "%")), vjust = -.4, size = 4) +
  scale_fill_manual(values = c("#D7301F", "#4575B4", "#1A9850")) +
  scale_y_continuous(expand = expansion(mult = c(0, .12))) +
  labs(title = "Metal mixture weights for stroke (survey-weighted qgcomp)",
       subtitle = sprintf("Mixture OR per quartile = %.2f (95%% CI %.2f–%.2f), P = %.3g",
                          exp(psi), exp(psi - 1.96 * psi_SE), exp(psi + 1.96 * psi_SE), p),
       x = NULL, y = "Relative weight (%)") + theme_bw(base_size = 12)
ggsave(file.path(OUT, "figures", "mixture_weights_svy_qgcomp.png"), p, width = 6.5, height = 5, dpi = 200)
cat("\nDONE\n")
