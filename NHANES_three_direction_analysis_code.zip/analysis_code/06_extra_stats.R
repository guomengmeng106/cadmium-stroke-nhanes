# 补充论文所需描述性统计：加权卒中患病率、暴露分布、RCS 非线性 P
library(arrow); library(dplyr); library(survey)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

df <- read_parquet(file.path(OUT, "analysis_clean.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  pir = INDFMPIR, bmi = BMXBMI,
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)

COV2 <- c("age","female","race","educ","pir","bmi","smoke","diabetes","hyperten","alcohol")
EXPS <- list(
  TyG          = list(v = c("TyG","TyG_BMI","TyG_WC","TyG_WHtR"), w = "wt_tyg"),
  Inflammation = list(v = c("SII","SIRI","NLR","PLR","MAR"),      w = "wt_mec"),
  Metals       = list(v = c("LBXBPB","LBXBCD","LBXTHG"),          w = "wt_pb")
)

rows <- list()
for (dirn in names(EXPS)) for (ev in EXPS[[dirn]]$v) {
  wt <- EXPS[[dirn]]$w
  req <- c(ev, wt, "stroke", COV2, "SDMVPSU", "SDMVSTRA")
  dd <- df %>% filter(if_all(all_of(req), ~ !is.na(.x))) %>% filter(.data[[wt]] > 0)
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = as.formula(paste0("~", wt)),
                   data = dd, nest = TRUE)
  prev <- svymean(~stroke, des)
  m1 <- svyquantile(as.formula(paste0("~", ev)), des, c(.25,.5,.75), na.rm = TRUE)
  q <- as.numeric(m1[[1]])
  rows[[paste(dirn, ev)]] <- data.frame(
    direction = dirn, exposure = ev, n = nrow(dd), n_stroke = sum(dd$stroke == 1),
    weighted_prev_pct = round(100 * as.numeric(prev[1]), 2),
    prev_se_pct = round(100 * as.numeric(SE(prev)), 2),
    p25 = round(q[1], 3), median = round(q[2], 3), p75 = round(q[3], 3),
    mean_cont = round(as.numeric(svymean(as.formula(paste0("~", ev)), des)[1]), 3)
  )
}
DESC <- bind_rows(rows)
write.csv(DESC, file.path(OUT, "descriptives.csv"), row.names = FALSE, fileEncoding = "UTF-8")
print(DESC)

# ------- RCS 非线性 P（全部主暴露）-------
rcs_p <- function(ev, wtvar) {
  req <- c(ev, wtvar, "stroke", COV2, "SDMVPSU", "SDMVSTRA")
  dd <- df %>% filter(if_all(all_of(req), ~ !is.na(.x))) %>% filter(.data[[wtvar]] > 0)
  dd$expR <- dd[[ev]]
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = as.formula(paste0("~", wtvar)),
                   data = dd, nest = TRUE)
  f  <- as.formula(paste("stroke ~ splines::ns(expR, df = 3) +", paste(COV2, collapse = " + ")))
  fl <- as.formula(paste("stroke ~ expR +", paste(COV2, collapse = " + ")))
  m  <- svyglm(f,  design = des, family = quasibinomial())
  ml <- svyglm(fl, design = des, family = quasibinomial())
  a <- anova(m, ml)
  data.frame(exposure = ev, P_overall = a$p[2], P_nonlinear = a$p[1], n = nrow(dd))
}
rcs_res <- bind_rows(lapply(c("TyG","TyG_WHtR"), rcs_p, wtvar = "wt_tyg"),
                     lapply(c("SII","MAR","SIRI"), rcs_p, wtvar = "wt_mec"),
                     lapply(c("LBXBPB","LBXBCD","LBXTHG"), rcs_p, wtvar = "wt_pb"))
write.csv(rcs_res, file.path(OUT, "rcs_pvalues.csv"), row.names = FALSE, fileEncoding = "UTF-8")
print(rcs_res)

# ------- 总体（全部 53459）加权卒中患病率 -------
cat("total analysis base n =", nrow(df), " strokes =", sum(df$stroke == 1, na.rm = TRUE), "\n")
cat("DONE\n")
