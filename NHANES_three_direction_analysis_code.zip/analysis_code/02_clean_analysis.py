# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""清洗+派生变量：TyG系列 / 炎症指标 / 重金属，输出 analysis_clean.parquet"""
import polars as pl
import numpy as np

df = pl.read_parquet(f"{OUT}/analysis_base.parquet")

NUMCOLS = [c for c in df.columns if c not in ("SEQN_new",)]
df = df.with_columns([
    pl.col(c).cast(pl.Float64, strict=False) for c in NUMCOLS if c != "SDDSRVYR"
] + [pl.col("SDDSRVYR").cast(pl.Int32, strict=False)])

# ---------- 样本筛选流程 ----------
flow = [("原始合并样本", df.height)]
d = df.filter(pl.col("SDDSRVYR") >= 1)  # 1999-2018 连续周期
flow.append(("连续周期 1999-2018 (SDDSRVYR 1-10)", d.height))
d = d.filter(pl.col("RIDAGEYR") >= 20)
flow.append(("成人 >=20 岁", d.height))
d = d.filter((pl.col("RIDEXPRG") != 1) | pl.col("RIDEXPRG").is_null())
flow.append(("非妊娠", d.height))
# 卒中结局明确 (1=Yes,2=No)
d = d.filter(pl.col("MCQ160F").is_in([1, 2]))
flow.append(("卒中自报明确 (MCQ160F 1/2)", d.height))

d = d.with_columns(stroke=(pl.col("MCQ160F") == 1).cast(pl.Int8))

# ---------- 特殊缺失码清洗 ----------
def clean_special(col, bads=(7, 9, 77, 99, 777, 999, 7777, 9999)):
    return pl.when(pl.col(col).is_in(list(bads))).then(None).otherwise(pl.col(col))

for c in ["DIQ010", "BPQ020", "HAR1", "HAR3", "ALQ101", "DMDEDUC2", "DMDMARTL"]:
    d = d.with_columns(clean_special(c).alias(c))

# ---------- 派生变量 ----------
d = d.with_columns([
    # TyG 系列 (mg/dL)
    (0.5 * pl.col("LBXTR") * pl.col("LBXGLU")).log().alias("TyG"),
    (pl.col("LBXTR") / pl.col("LBDHDD")).alias("TG_HDL"),
])
d = d.with_columns([
    (pl.col("TyG") * pl.col("BMXBMI")).alias("TyG_BMI"),
    (pl.col("TyG") * pl.col("BMXWAIST")).alias("TyG_WC"),
    (pl.col("TyG") * pl.col("BMXWAIST") / pl.col("BMXHT")).alias("TyG_WHtR"),
])
d = d.with_columns([
    # 炎症复合指标
    (pl.col("LBXPLTSI") * pl.col("LBDNENO") / pl.col("LBDLYMNO")).alias("SII"),
    (pl.col("LBDNENO") * pl.col("LBDMONO") / pl.col("LBDLYMNO")).alias("SIRI"),
    (pl.col("LBDNENO") / pl.col("LBDLYMNO")).alias("NLR"),
    (pl.col("LBXPLTSI") / pl.col("LBDLYMNO")).alias("PLR"),
    (pl.col("LBDMONO") / pl.col("LBXSAL")).alias("MAR"),
])
# 吸烟状态（血清可替卡宁客观定义；SMQ 在该 harmonized 数据集缺失）
# <1 非吸烟 / 1-10 被动或既往 / >=10 当前吸烟（NHANES 常用阈值）
d = d.with_columns(
    pl.when(pl.col("LBXCOT") >= 10).then(pl.lit("current"))
    .when(pl.col("LBXCOT") >= 1).then(pl.lit("former_passive"))
    .when(pl.col("LBXCOT") >= 0).then(pl.lit("non"))
    .otherwise(None).alias("smoke")
)
d = d.with_columns([
    (pl.col("DIQ010") == 1).cast(pl.Int8).alias("diabetes"),
    (pl.col("BPQ020") == 1).cast(pl.Int8).alias("hyperten"),
    (pl.col("ALQ101") == 1).cast(pl.Int8).alias("alcohol"),
    (pl.col("RIAGENDR") == 2).cast(pl.Int8).alias("female"),
])
# 合并 10 周期权重
d = d.with_columns([
    (pl.col("WTSAF2YR") / 10).alias("wt_tyg"),
    (pl.col("WTMEC2YR") / 10).alias("wt_mec"),
    (pl.col("WT_LBXBPB") / 10).alias("wt_pb"),
    (pl.col("WT_LBXBCD") / 10).alias("wt_cd"),
    (pl.col("WT_LBXTHG") / 10).alias("wt_hg"),
])

# ---------- 各分析方向可用样本 ----------
avail = {
    "TyG分析(需空腹TG+GLU+权重)": d.filter(
        pl.col("TyG").is_not_null() & pl.col("wt_tyg").is_not_null() & (pl.col("wt_tyg") > 0)).height,
    "炎症分析(需CBC+白蛋白+MEC权重)": d.filter(
        pl.col("SII").is_not_null() & pl.col("LBXSAL").is_not_null()
        & pl.col("wt_mec").is_not_null() & (pl.col("wt_mec") > 0)).height,
    "重金属分析(需血铅镉汞+权重)": d.filter(
        pl.col("LBXBPB").is_not_null() & pl.col("LBXBCD").is_not_null() & pl.col("LBXTHG").is_not_null()
        & pl.col("wt_pb").is_not_null() & (pl.col("wt_pb") > 0)).height,
}

print("=== 样本筛选流程 ===")
for k, v in flow:
    print(f"  {k}: {v}")
print("\n=== 各方向可用样本 ===")
for k, v in avail.items():
    n_stroke = 0
    print(f"  {k}: {v}")
print("\n=== 关键变量缺失率 ===")
chk = ["stroke", "TyG", "TyG_BMI", "TyG_WC", "TyG_WHtR", "SII", "SIRI", "NLR", "MAR",
       "LBXBPB", "LBXBCD", "LBXTHG", "smoke", "diabetes", "hyperten", "BMXBMI"]
for c in chk:
    nn = d[c].null_count()
    print(f"  {c:10s} missing {nn:6d} ({nn/d.height*100:.1f}%)")

print("\n=== HAR3 / DIQ010 分布(验证编码) ===")
print(d.group_by("HAR3").len().sort("HAR3"))
print(d.group_by("DIQ010").len().sort("DIQ010"))
print("\n=== stroke 分布 ===")
print(d.group_by("stroke").len())

d.write_parquet(f"{OUT}/analysis_clean.parquet")
print("\nsaved analysis_clean.parquet", d.shape)
