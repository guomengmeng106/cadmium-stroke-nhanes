# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

options(warn = 1)
rdata <- Sys.getenv("NHANES_RDATA", "D:/数据库/NHANME/w - nhanes_1988_2018.RData")
outdir <- OUT
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)
e <- new.env()
load(rdata, envir = e)
objs <- ls(e)
cat("=== objects in RData ===\n")
for (nm in objs) {
  o <- e[[nm]]
  sz <- if (is.data.frame(o)) paste(dim(o), collapse = "x") else length(o)
  cat(sprintf("%-40s %-12s %s\n", nm, class(o)[1], sz))
}
for (nm in c("df_dictionary", "df_levels_categorical_variables", "df_medications_drug_info")) {
  if (exists(nm, envir = e)) {
    write.csv(e[[nm]], file.path(outdir, paste0(nm, ".csv")), row.names = FALSE, fileEncoding = "UTF-8")
    cat("exported:", nm, "\n")
  }
}
cat("DONE\n")
