@echo off
REM 一键复现 NHANES 三方向分析（Windows）
REM 用法: run_all.bat A | B | C | ALL
REM 如需覆盖路径，先执行:
REM   set NHANES_OUT=D:\my_project\output
REM   set NHANES_DATA=E:\NHANES\clean

setlocal
if "%PY%"=="" set PY=python
if "%RS%"=="" set RS=Rscript
set HERE=%~dp0
set STAGE=%1
if "%STAGE%"=="" set STAGE=A

if /i "%STAGE%"=="A" goto :A
if /i "%STAGE%"=="B" goto :B
if /i "%STAGE%"=="C" goto :C
if /i "%STAGE%"=="ALL" goto :ALL
echo Usage: run_all.bat A ^| B ^| C ^| ALL
exit /b 1

:A
echo =========== Stage A: 三方向核心分析 ===========
"%RS%" "%HERE%00_extract_dictionary.R" || exit /b 1
"%PY%" "%HERE%01_build_dataset.py" || exit /b 1
"%PY%" "%HERE%02_clean_analysis.py" || exit /b 1
"%RS%" "%HERE%03_analyze_survey.R" || exit /b 1
"%RS%" "%HERE%04_rcs_nonlinearity.R" || exit /b 1
"%RS%" "%HERE%05_table1_subgroup.R" || exit /b 1
"%RS%" "%HERE%06_extra_stats.R" || exit /b 1
"%RS%" "%HERE%07_redraw_forest.R" || exit /b 1
echo =========== Stage A 完成 ===========
goto :EOF

:B
echo =========== Stage B: 扩展分析 ===========
"%PY%" "%HERE%10_build_dataset2.py" || exit /b 1
"%PY%" "%HERE%11_clean_dataset2.py" || exit /b 1
"%RS%" "%HERE%12_cox_mortality.R" || exit /b 1
"%RS%" "%HERE%13_mixture_wqs.R" || exit /b 1
"%RS%" "%HERE%14_reviewer_sensitivity.R" || exit /b 1
"%RS%" "%HERE%figures\plot_cox.R" || exit /b 1
"%PY%" "%HERE%figures\plot_flow.py" || exit /b 1
"%RS%" "%HERE%figures\plot_jos_figs.R" || exit /b 1
"%RS%" "%HERE%figures\plot_jos_forests.R" || exit /b 1
echo =========== Stage B 完成 ===========
goto :EOF

:C
echo =========== Stage C: 稿件与投稿包 ===========
"%PY%" "%HERE%manuscript\build_jos_manuscript.py" || exit /b 1
"%PY%" "%HERE%manuscript\build_jos_package.py" || exit /b 1
"%PY%" "%HERE%manuscript\build_review_report.py" || exit /b 1
echo =========== Stage C 完成 ===========
goto :EOF

:ALL
call :A || exit /b 1
call :B || exit /b 1
call :C || exit /b 1
echo =========== 全部完成 ===========
goto :EOF
