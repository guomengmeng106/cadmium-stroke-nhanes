# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""清洗第二轮底表：加入死亡随访标志、死因、随访时长、海鲜/n-3 摄入"""
import polars as pl

d = pl.read_parquet(f"{OUT}/analysis_base2.parquet")

NUM = [c for c in d.columns if c not in ("SEQN_new",)]
d = d.with_columns([pl.col(c).cast(pl.Float64, strict=False) for c in NUM])

# 样本筛选：1999-2018 成人 / 非妊娠 / 卒中自报明确
flow = [("原始合并样本", d.height)]
d = d.filter(pl.col("SDDSRVYR") >= 1)
flow.append(("连续周期 1999-2018", d.height))
d = d.filter(pl.col("RIDAGEYR") >= 20)
flow.append(("成人 >=20 岁", d.height))
d = d.filter((pl.col("RIDEXPRG") != 1) | pl.col("RIDEXPRG").is_null())
flow.append(("非妊娠", d.height))
d = d.filter(pl.col("MCQ160F").is_in([1, 2]))
flow.append(("卒中自报明确", d.height))

d = d.with_columns(stroke=(pl.col("MCQ160F") == 1).cast(pl.Int8))

# 特殊缺失码
def clean_special(col, bads=(7, 9, 77, 99, 777, 999, 7777, 9999)):
    return pl.when(pl.col(col).is_in(list(bads))).then(None).otherwise(pl.col(col))

for c in ["DIQ010", "BPQ020", "HAR1", "HAR3", "ALQ101", "DMDEDUC2", "DMDMARTL"]:
    d = d.with_columns(clean_special(c).alias(c))

# 派生（与 clean_analysis.py 保持一致）
d = d.with_columns([
    (0.5 * pl.col("LBXTR") * pl.col("LBXGLU")).log().alias("TyG"),
    (pl.col("LBXPLTSI") * pl.col("LBDNENO") / pl.col("LBDLYMNO")).alias("SII"),
    (pl.col("LBDNENO") * pl.col("LBDMONO") / pl.col("LBDLYMNO")).alias("SIRI"),
    (pl.col("LBDNENO") / pl.col("LBDLYMNO")).alias("NLR"),
    (pl.col("LBXPLTSI") / pl.col("LBDLYMNO")).alias("PLR"),
    (pl.col("LBDMONO") / pl.col("LBXSAL")).alias("MAR"),
])
d = d.with_columns([
    (pl.col("TyG") * pl.col("BMXBMI")).alias("TyG_BMI"),
    (pl.col("TyG") * pl.col("BMXWAIST")).alias("TyG_WC"),
    (pl.col("TyG") * pl.col("BMXWAIST") / pl.col("BMXHT")).alias("TyG_WHtR"),
])
d = d.with_columns(
    pl.when(pl.col("LBXCOT") >= 10).then(pl.lit("current"))
    .when(pl.col("LBXCOT") >= 1).then(pl.lit("former_passive"))
    .when(pl.col("LBXCOT") >= 0).then(pl.lit("non"))
    .otherwise(None).alias("smoke")
)
d = d.with_columns([
    (pl.col("DIQ010") == 1).cast(pl.Int8).alias("diabetes"),
    (pl.col("BPQ020") == 1).cast(pl.Int8).alias("hyperten"),
    (pl.col("ALQ101") == 1).cast(pl.Int8).alias("alcohol"),
    (pl.col("RIAGENDR") == 2).cast(pl.Int8).alias("female"),
    (pl.col("WTMEC2YR") / 10).alias("wt_mec"),
    (pl.col("WT_LBXBPB") / 10).alias("wt_pb"),
    (pl.col("WTSAF2YR") / 10).alias("wt_tyg"),
])

# ---------- 死亡随访变量 ----------
d = d.with_columns([
    # 0=存活/删失 1=死亡
    pl.when(pl.col("MORTSTAT") == 1).then(1).otherwise(0).alias("d_all"),
    pl.when((pl.col("MORTSTAT") == 1) & pl.col("UCOD_LEADING").is_in([1.0, 5.0])).then(1).otherwise(0).alias("d_cvd"),
    pl.when((pl.col("MORTSTAT") == 1) & (pl.col("UCOD_LEADING") == 5.0)).then(1).otherwise(0).alias("d_cbv"),
    pl.when((pl.col("MORTSTAT") == 1) & (pl.col("UCOD_LEADING") == 1.0)).then(1).otherwise(0).alias("d_chd"),
    (pl.col("PERMTH_EXM") / 12).alias("fuyr_exm"),           # 随访年
    (pl.col("ELIGSTAT") == 1).cast(pl.Int8).alias("mort_elig"),
])

print("=== 样本筛选流程 ===")
for k, v in flow:
    print(f"  {k}: {v}")

print("\n=== 死亡随访可用性 ===")
print("  ELIGSTAT=1:", d.filter(pl.col("mort_elig") == 1).height)
print("  PERMTH_EXM>0:", d.filter(pl.col("PERMTH_EXM") > 0).height)
print("  全因死亡:", d["d_all"].sum(), "| CVD(心+脑) 死亡:", d["d_cvd"].sum(),
      "| 脑血管死亡:", d["d_cbv"].sum(), "| 心脏病死亡:", d["d_chd"].sum())
print("  随访年: min/median/max =",
      d.select(pl.col("fuyr_exm").min().alias("min"), pl.col("fuyr_exm").median().round(1).alias("med"),
               pl.col("fuyr_exm").max().round(1).alias("max")).to_dicts())

print("\n=== 海鲜/n-3 摄入覆盖率 ===")
for c in ["DRXT_PF_SEAFD_HI", "DRXT_PF_SEAFD_LOW", "DRXT_PF_TOTAL", "DRXTP205", "DRXTP226"]:
    nn = d[c].null_count()
    med = d.select(pl.col(c).median().round(3)).item()
    print(f"  {c:20s} missing {nn:6d} ({nn / d.height * 100:4.1f}%)  median={med}")

d.write_parquet(f"{OUT}/analysis_clean2.parquet")
print(f"\nsaved analysis_clean2.parquet  shape={d.shape}")
