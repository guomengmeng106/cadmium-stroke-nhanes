# RCS 曲线（预计算 ns basis 列，固定 knots 预测）
library(arrow); library(dplyr); library(survey); library(ggplot2)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

df <- read_parquet(file.path(OUT, "analysis_clean.parquet"))
df <- df %>% mutate(
  age = RIDAGEYR,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White", "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  pir = INDFMPIR, bmi = BMXBMI,
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)
COV2 <- c("age", "female", "race", "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")

rcs_plot <- function(ev, wtvar, dirn) {
  req <- c(ev, wtvar, "stroke", COV2, "SDMVPSU", "SDMVSTRA")
  dd <- df %>% filter(if_all(all_of(req), ~ !is.na(.x))) %>% filter(.data[[wtvar]] > 0)
  bb <- splines::ns(dd[[ev]], df = 3)
  kn <- attr(bb, "knots"); bk <- attr(bb, "Boundary.knots")
  dd$ns1 <- bb[, 1]; dd$ns2 <- bb[, 2]; dd$ns3 <- bb[, 3]
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA,
                   weights = as.formula(paste0("~", wtvar)), data = dd, nest = TRUE)
  f <- as.formula(paste("stroke ~ ns1 + ns2 + ns3 +", paste(COV2, collapse = " + ")))
  m <- svyglm(f, design = des, family = quasibinomial())
  # 非线性 P 值：联合检验 ns1-ns3（与仅有线性项比较）
  m_lin <- svyglm(as.formula(paste("stroke ~ ", ev, " + ", paste(COV2, collapse = " + "))),
                  design = des, family = quasibinomial())
  a <- anova(m, m_lin)
  p_nonlin <- a$p
  grid <- seq(quantile(dd[[ev]], .01), quantile(dd[[ev]], .99), length.out = 100)
  ref <- median(dd[[ev]])
  nb <- splines::ns(grid, knots = kn, Boundary.knots = bk)
  rb <- splines::ns(ref, knots = kn, Boundary.knots = bk)
  dif <- sweep(nb, 2, as.vector(rb), "-")
  idx <- c("ns1", "ns2", "ns3")
  cf <- coef(m)[idx]; V <- vcov(m)[idx, idx]
  lp <- as.vector(dif %*% cf)
  se <- sqrt(pmax(rowSums((dif %*% V) * dif), 0))
  pd <- data.frame(x = grid, OR = exp(lp), lo = exp(lp - 1.96 * se), hi = exp(lp + 1.96 * se))
  p <- ggplot(pd, aes(x, OR)) +
    geom_ribbon(aes(ymin = lo, ymax = hi), alpha = 0.2, fill = "#2C7FB8") +
    geom_line(color = "#D7301F", linewidth = 1) +
    geom_hline(yintercept = 1, linetype = 2, color = "grey50") +
    coord_cartesian(ylim = c(0, min(max(pd$hi, na.rm = TRUE), 10))) +
    labs(title = paste0("RCS: ", ev, " vs stroke (weighted)"),
         subtitle = sprintf("P for nonlinearity = %.3f | n = %d | ref = median %.2f", p_nonlin, nrow(dd), ref),
         x = ev, y = "OR (95% CI)") + theme_bw(base_size = 11)
  ggsave(file.path(OUT, "figures", paste0("rcs_", dirn, "_", ev, ".png")), p, width = 7, height = 5, dpi = 150)
  cat("rcs done:", dirn, ev, " P_nonlin =", round(p_nonlin, 4), "\n")
}
rcs_plot("TyG", "wt_tyg", "TyG")
rcs_plot("TyG_WHtR", "wt_tyg", "TyG")
rcs_plot("SII", "wt_mec", "Inflammation")
rcs_plot("MAR", "wt_mec", "Inflammation")
rcs_plot("LBXBPB", "wt_pb", "Metals")
cat("DONE\n")
