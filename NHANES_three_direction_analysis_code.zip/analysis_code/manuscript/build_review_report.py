# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""生成 Journal of Stroke 模拟审稿报告"""
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from build_jos_package import setup_doc, para, heading, page_break  # 复用排版

DST = os.path.join(OUT, "submission_JoS/JoS_Review_Report.docx")

doc = setup_doc()
para(doc, "Manuscript Review Report", size=16, bold=True, center=True)
para(doc, "Manuscript: “Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999–2018”", center=True)
para(doc, "Target journal: Journal of Stroke (simulated pre-submission review, 19-Sep-2026)", center=True)
para(doc, "")

heading(doc, "Part 1. Handling Editor Assessment", size=13)
para(doc, "Summary judgement: MAJOR REVISION before this manuscript reaches review-ready state.")
para(doc, "The question is timely and the dataset is powerful: a head-to-head comparison of environmental metals versus metabolic-inflammatory markers for stroke, triangulated with NDI-linked mortality, is a genuine increment over the existing NHANES metal-stroke literature. The writing is disciplined and the limitations are unusually candid. However, I identify one internal inconsistency in the exposure description (M1), several analytic-reporting gaps that a methods reviewer will seize (M2, M6, M7), and a set of presentation-level defects. None appears fatal; all are repairable within one revision cycle. Novelty is moderate rather than high: the seven-metal mixture analysis by Huang et al. (Front Nutr 2025; cited as ref 3) already occupies adjacent territory, so the manuscript must lean on its unique elements (the three-way pathway comparison, the mortality linkage, and the mercury-seafood falsification attempt) to justify placement.")
para(doc, "Scope check against journal aims: risk-factor observational epidemiology is within JoS scope; the environmental-exposure angle is acceptable provided the clinical relevance for stroke prevention is kept foregrounded, which the Discussion does.")

heading(doc, "Part 2. Reviewer 1 (Methods / Environmental Epidemiology)", size=13)

heading(doc, "Major comments", size=12)
para(doc, "M1. Internal inconsistency in exposure description. Methods states that the three metals “share one set of analysis weights (identical in all 36,781 available records)”, yet the mercury analytic sample (n=26,232) is substantially smaller than the lead/cadmium sample (n=31,275). If the measurements truly came from one identical sub-sample, the analytic ns could not differ. The explanation — blood mercury was not measured in all cycles — must be stated explicitly, and the weight-concordance sentence should be reworded so readers do not infer a single common measurement occasion. As written, this single sentence undermines confidence in the sampling description.")
para(doc, "M2. Linked-mortality file version not reported. The Cox analyses must state which NCHS Linked Mortality File release was used (e.g., the 2019 public-use LMF), how eligibility (ELIGSTAT) was handled, and confirm that the same follow-up end-date applies across all ten cycles. Different follow-up windows across cycles would introduce differential censoring that the current Methods do not address.")
para(doc, "M3. Competing risks. Treating non-cerebrovascular deaths as censoring in the cerebrovascular mortality model is conventional but should be acknowledged; ideally a Fine-Gray sensitivity analysis (or a cause-specific hazard statement) should accompany the 199-event cerebrovascular analysis, and the small event count should temper the null interpretation, which the Discussion does well but the abstract’s flat statement “not cerebrovascular mortality (0.97; 199 events)” understates.")
para(doc, "M6. The mercury-seafood falsification was performed only for the cross-sectional stroke outcome. Yet the outcome-specificity argument in the Discussion rests on the INVERSE MERCURY association with cerebrovascular mortality (HR 0.68). If seafood confounding is being invoked and tested at all, the same adjustment must be shown for the mortality outcome on which the argument depends. This is a readily fixable analytic gap.")
para(doc, "M7. Mediator adjustment and renal confounding. Model 2 adjusts diabetes and hypertension, which sit on the causal path from metals to stroke; the manuscript should state explicitly that Model 2 therefore estimates associations independent of these intermediates (direct-effect interpretation), and that total-effect estimates are given by the cruder models. Second, cadmium handling is renal-dependent: without eGFR or serum creatinine adjustment, blood cadmium associations may partly reflect reverse causation via renal impairment. NHANES contains creatinine; an eGFR-adjusted sensitivity model for the cadmium-stroke and cadmium-mortality associations is strongly recommended.")
para(doc, "M5. Abstract wording. “With positive non-linearity” is not a standard term — report “with significant non-linearity (P=0.004)”. “Attenuated this by less than 9%” should give the actual range (3.6%–8.3%). The phrase “Seafood-derived n-3 intake was added to test the ‘mercury-fish’ explanation” is colloquial; use “seafood-intake confounding (the ‘mercury–fish’ paradox)”.")

heading(doc, "Minor comments", size=12)
para(doc, "m1. Title page data on the anonymised first page must be complete in themselves (word count 4,125; 4 figures; 3 tables) rather than cross-referencing the title page file.")
para(doc, "m2. The ethics statement appears twice (end of Data source section and again as a standalone Ethics statement); delete the first.")
para(doc, "m7. Residual internal cross-reference “(Section 4.3)” in the Discussion; Discussion has no numbered sections. Replace with a plain-language pointer or delete.")
para(doc, "m8. Harmonize spelling: “Harmonized/Harmonized NHANES” versus “variable-harmonised compilation”. Replace “uninformative but important” with “negative but informative”.")
para(doc, "m10. Journal style requires SI units with conventional units in parentheses; blood lead is customarily reported in µg/dL — add a table note stating the unit convention.")
para(doc, "m11. Figure 2 legend should explain that “P trend” rows are per-quartile-increment odds ratios from the ordinal trend model, not P values.")
para(doc, "m13. Reference 11 (J King Saud Univ Sci) lacks volume/pages; JoS requires either full bibliographic data or the in-press format with DOI and a copy supplied to the editorial office.")

heading(doc, "Part 3. Reviewer 2 (Stroke Neurology / Clinical Epidemiology)", size=13)
heading(doc, "Major comments", size=12)
para(doc, "C1. Stroke phenotyping. Self-reported stroke (MCQ160F) without ischemic/hemorrhagic subtyping is the manuscript’s largest clinical vulnerability. The manuscript handles this reasonably (ref 15 validation), but for a stroke journal the authors should add one sentence on what subtype misclassification most plausibly does to the metal estimates (e.g., differential capture of hemorrhagic stroke by cadmium-related hypertension) and discuss why no imaging or subtype data were used.")
para(doc, "C2. The prevalence-versus-mortality divergence is the intellectually honest core of this paper and deserves its current prominence. However, the abstract’s conclusion sentence (“the cross-sectional stroke association and the inverse mercury association warrant confirmation in incident-stroke cohorts”) reads as boilerplate; consider instead a concrete statement of what the null cerebrovascular-mortality result means for the clinical claim (e.g., that cadmium stratification may operate primarily through coronary atherosclerosis rather than stroke-specific pathways).")
para(doc, "C3. Clinical translatability. The Discussion proposes adding environmental exposure questions to routine stroke-risk assessment; this over-reaches cross-sectional prevalence odds ratios. Either soften to a research agenda statement or anchor it to the prospective coronary findings, which are the only causal-grade evidence in the paper.")
para(doc, "C4. Table 1: report the survey-weighted stroke prevalence (approximately 3%) and add a footnote that hs-CRP and lipid values in prevalent stroke are susceptible to post-event treatment (statins), which the text discusses but the table does not flag.")

heading(doc, "Part 4. Priority Action List (author-facing)", size=13)
para(doc, "Must fix before submission (data or factual): M1 exposure/weighting description; M2 LMF version; M6 seafood-adjusted Cox for cerebrovascular mortality; reference 11 bibliographic completion; title-page statistics; m2 duplicate ethics; m7 residual cross-reference.")
para(doc, "Should fix if feasible: M7 eGFR-adjusted sensitivity models; M3 competing-risk statement or Fine-Gray sensitivity; C1 subtype-misclassification sentence.")
para(doc, "Presentation: M5, m1, m8, m10, m11, C2-C4, abstract tightening.")
para(doc, "")
para(doc, "Overall recommendation: Revise and resubmit (major). Anticipated review outcome after repair: acceptable with minor revisions.")
doc.save(DST)
print("saved", DST)
