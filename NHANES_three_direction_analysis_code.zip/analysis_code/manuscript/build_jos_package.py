# -*- coding: utf-8 -*-
"""Journal of Stroke 投稿包生成器：主文档 + 标题页 + Cover Letter + 补充材料
格式：TNR 12, 双倍行距, 2.5cm 页边距, 左对齐, 页码底部居中, 表格仅横线, 上标引用"""
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

MS = rf"{BASE}/manuscript"
SUB = rf"{BASE}/submission_JoS"

SUP_MAP = {"⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
           "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "·": ","}


def setup_doc():
    doc = Document()
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Cm(2.5)
        s.left_margin = s.right_margin = Cm(2.5)
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    pf.line_spacing = 2.0
    pf.space_after = Pt(0)
    # 页码底部居中
    footer = doc.sections[0].footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run()
    fld1 = OxmlElement("w:fldChar"); fld1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = "PAGE"
    fld2 = OxmlElement("w:fldChar"); fld2.set(qn("w:fldCharType"), "end")
    run._r.append(fld1); run._r.append(instr); run._r.append(fld2)
    return doc


def add_runs(p, text, size=12, base_bold=False, base_italic=False):
    """支持 **粗体** 与 unicode 上标 -> superscript"""
    for seg in re.split(r"(\*\*[^*]+\*\*)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            buf, i, sup = seg[2:-2], 0, False
        else:
            buf, i, sup = seg, 0, False
        # 逐字符处理上标
        j = 0
        while j < len(buf):
            ch = buf[j]
            if ch in SUP_MAP:
                k = j
                sup_chars = []
                while k < len(buf) and buf[k] in SUP_MAP:
                    sup_chars.append(SUP_MAP[buf[k]]); k += 1
                r = p.add_run("".join(sup_chars))
                r.font.superscript = True
                r.font.size = Pt(size)
                if seg.startswith("**"):
                    r.bold = True
                j = k
            else:
                k = j
                plain = []
                while k < len(buf) and buf[k] not in SUP_MAP:
                    plain.append(buf[k]); k += 1
                r = p.add_run("".join(plain))
                r.font.size = Pt(size)
                if seg.startswith("**"):
                    r.bold = True
                if base_bold:
                    r.bold = True
                if base_italic:
                    r.italic = True
                j = k


def para(doc, text, size=12, bold=False, italic=False, align=None, center=False):
    p = doc.add_paragraph()
    add_runs(p, text, size=size, base_bold=bold, base_italic=italic)
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 2.0
    p.paragraph_format.space_after = Pt(0)
    return p


def heading(doc, text, size=12):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(size)
    p.paragraph_format.line_spacing = 2.0
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(0)
    return p


def page_break(doc):
    from docx.enum.text import WD_BREAK
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


def no_vline_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge, val in [("top", "single"), ("left", "none"), ("bottom", "single"),
                      ("right", "none"), ("insideH", "single"), ("insideV", "none")]:
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), val)
        el.set(qn("w:sz"), "8")
        borders.append(el)
    tblPr.append(borders)


def add_table(doc, rows):
    ncols = max(len(r) for r in rows)
    t = doc.add_table(rows=len(rows), cols=ncols)
    no_vline_borders(t)
    for ri, row in enumerate(rows):
        for ci in range(ncols):
            cell = t.cell(ri, ci)
            txt = row[ci] if ci < len(row) else ""
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.line_spacing = 1.0
            add_runs(p, txt, size=9)
            if ri == 0:
                for r in p.runs:
                    r.bold = True
    return t


def parse_md(doc, path, skip_h1=True):
    lines = open(path, encoding="utf-8").read().split("\n")
    i, n = 0, len(lines)
    while i < n:
        ln = lines[i].rstrip()
        s = ln.strip()
        if s == "[PAGEBREAK]":
            page_break(doc); i += 1; continue
        if s in ("---", ""):
            i += 1; continue
        if s.startswith("# ") and not skip_h1:
            para(doc, s[2:], size=14, bold=True, center=True)
        elif s.startswith("## "):
            page_break(doc)
            heading(doc, s[3:])
        elif s.startswith("### "):
            heading(doc, s[4:], size=12)
        elif s.startswith("|"):
            tbl = []
            while i < n and lines[i].strip().startswith("|"):
                row = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(set(c) <= set("-: ") for c in row):
                    tbl.append(row)
                i += 1
            if tbl:
                page_break(doc)
                add_table(doc, tbl)
            continue
        elif s.startswith("- "):
            para(doc, "• " + s[2:])
        elif re.match(r"^\d+\.\s", s):
            para(doc, s)
        else:
            para(doc, s)
        i += 1


# ============ 1. 主文档 ============
doc = setup_doc()
parse_md(doc, rf"{SUB}/JoS_Main_Manuscript.md", skip_h1=False)
doc.save(rf"{SUB}/JoS_Main_Manuscript.docx")
print("saved JoS_Main_Manuscript.docx")

# ============ 2. Title page ============
doc = setup_doc()
para(doc, "Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999–2018",
     size=14, bold=True, center=True)
para(doc, "")
para(doc, "Running title: Cadmium and stroke in NHANES 1999–2018")
para(doc, "Title: 99 characters (including spaces)")
para(doc, "Word count (main text, Introduction through Conclusions): 4,379")
para(doc, "Figures: 4 (plus 1 supplementary figure)   Tables: 3 (plus 5 supplementary tables)")
para(doc, "")
para(doc, "Mengmeng Guo^1,2†, Lu Cong^1,2†, Zunjing Liu^1,2*")
para(doc, "")
para(doc, "1. Department of Neurology, Peking University People's Hospital, Beijing 100044, China")
para(doc, "2. Peking University Health Science Center, Beijing 100191, China")
para(doc, "")
para(doc, "†These authors contributed equally to this work and should be considered co-first authors.")
para(doc, "*Corresponding author: Zunjing Liu")
para(doc, "Department of Neurology, Peking University People's Hospital")
para(doc, "No. 11 Xizhimen South Street, Xicheng District, Beijing 100044, China")
para(doc, "E-mail: [待填]   ORCID: [待填]   Tel: [待填]")
para(doc, "")
para(doc, "Funding: This work was supported by the China Postdoctoral Science Foundation (Grant No. 2025M772029) and the Peking University People's Hospital Talent Introduction Scientific Research Launch Fund (2022-T-02).")
para(doc, "")
para(doc, "Keywords: Stroke; Cadmium; Lead; Mercury; Environmental Exposure; Metals, Heavy")
doc.save(rf"{SUB}/JoS_Title_Page.docx")
print("saved JoS_Title_Page.docx")

# ============ 3. Cover letter ============
doc = setup_doc()
cl = [
    ("To the Editor-in-Chief,", False),
    ("Journal of Stroke", False),
    ("", False),
    ("Dear Editor-in-Chief,", False),
    ("We submit the enclosed manuscript entitled “Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999–2018” for consideration as an Original Article.", False),
    ("Identifying modifiable contributors to the residual burden of stroke remains a priority. In a nationally representative sample of 53,459 US adults, we found that low-level blood cadmium was associated with stroke prevalence in a strong, non-linear dose-response (highest vs lowest quartile odds ratio 1.86, 95% CI 1.31–2.64), that cadmium dominated the joint effect of the lead-cadmium-mercury mixture (55.5% of positive weight by survey-weighted quantile g-computation), and that cadmium independently predicted cardiovascular (HR 1.16) and coronary (HR 1.18) mortality over a median 9 years of National Death Index follow-up. The inverse mercury association was not explained by measured seafood or n-3 intake. The cadmium association was strongest in never-smokers, a finding with direct implications as smoking-related exposure declines. We note candidly that the prospective cerebrovascular-mortality association was null (HR 0.97, 199 events) while the coronary-mortality association was strong (HR 1.18); we discuss this divergence at length and temper our clinical conclusions accordingly. We believe these data add a rigorously weighted, mortality-linked perspective to the environmental contribution to stroke risk.", False),
    ("The manuscript reports original work. All authors have read and approved the submitted manuscript, the manuscript has not been submitted elsewhere nor published elsewhere in whole or in part, except as an abstract (if relevant).", False),
    ("Ethics: the NHANES protocol was approved by the NCHS Ethics Review Board and all participants provided written informed consent. The authors declare no conflicts of interest related to this study. [修改:如有个别作者需披露,请补充]", False),
    ("Corresponding author: Zunjing Liu, Department of Neurology, Peking University People's Hospital, No. 11 Xizhimen South Street, Xicheng District, Beijing 100044, China. E-mail: [待填]; Tel: [待填]; ORCID: [待填].", False),
    ("Suggested reviewers: (1) Yangbo Sun, PhD, Assistant Professor, Department of Preventive Medicine, College of Medicine, University of Tennessee Health Science Center, Memphis, TN, USA; ysun80@uthsc.edu. (2) Zumin Shi, PhD, Professor, Department of Nutrition Sciences, College of Health Sciences, Qatar University, Doha, Qatar; Zumin@qu.edu.qa. (3) Jiachen Liu, MD, Postdoctoral Scholar, School of Medicine, Washington University in St. Louis, St. Louis, MO, USA; jia-chen@wustl.edu.", False),
    ("Thank you for your consideration.", False),
    ("Sincerely,", False),
    ("Zunjing Liu, on behalf of all authors", False),
]
for txt, b in cl:
    if txt == "":
        para(doc, "")
    else:
        para(doc, txt)
doc.save(rf"{SUB}/JoS_Cover_Letter.docx")
print("saved JoS_Cover_Letter.docx")

# ============ 4. Supplementary ============
en = open(rf"{MS}/NHANES_stroke_manuscript_EN.md", encoding="utf-8").read()
cn = open(rf"{MS}/NHANES_stroke_manuscript.md", encoding="utf-8").read()

def extract_table_md(start_title, end_title):
    i = en.find(start_title)
    j = en.find(end_title) if end_title else len(en)
    blk = en[i:j]
    return [l for l in blk.split("\n") if l.strip().startswith("|") or l.strip().startswith("**")]

doc = setup_doc()
para(doc, "Supplementary Material", size=14, bold=True, center=True)
para(doc, "Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999–2018", italic=True, center=True)
para(doc, "")

heading(doc, "Supplementary Methods")
para(doc, "Analytic code (Python 3.13/polars for data assembly; R 4.6.0 with the survey, qgcomp and ggplot2 packages for modelling) is available from the corresponding author upon reasonable request. The Harmonized NHANES 1988–2018 dataset and the NDI-linked mortality file are publicly available from the CDC/NCHS repository.")

def emit_table(title, start, end):
    page_break(doc)
    heading(doc, title, size=11)
    rows = extract_table_md(start, end)
    rows = [r for r in rows if not r.strip().startswith("**")]
    tbl = []
    for l in rows:
        row = [c.strip() for c in l.strip().strip("|").split("|")]
        if not all(set(c) <= set("-: ") for c in row):
            tbl.append(row)
    if tbl:
        add_table(doc, tbl)

# S1 在中文版中（英文版 Tables 区未含），从中文稿提取
page_break(doc)
heading(doc, "Supplementary Table S1. Distribution of exposures (weighted median and interquartile range)", size=11)
i = cn.find("### Supplementary Table S1.")
blk = cn[i:]
tbl = []
for l in blk.split("\n"):
    ls = l.strip()
    if not ls.startswith("|"):
        if tbl:
            break
        continue
    row = [c.strip() for c in ls.strip("|").split("|")]
    if all(set(c) <= set("-: ") for c in row):
        continue
    tbl.append(row)
add_table(doc, tbl)
# S2: 炎症 + TyG（从原 Table 2 提取）
page_break(doc)
heading(doc, "Supplementary Table S2. Associations of inflammatory and TyG indices with stroke prevalence (weighted logistic regression)", size=11)
i = en.find("### Table 2.")
j = en.find("### Table 3.")
blk = en[i:j]
tbl = []
for l in blk.split("\n"):
    ls = l.strip()
    if not ls.startswith("|"):
        continue
    row = [c.strip() for c in ls.strip("|").split("|")]
    if all(set(c) <= set("-: ") for c in row):
        continue
    if row and (row[0].startswith("**Inflammation") or row[0].startswith("**TyG") or
                row[0].startswith("SII") or row[0].startswith("SIRI") or row[0].startswith("NLR") or
                row[0].startswith("PLR") or row[0].startswith("MAR") or row[0].startswith("TyG") or
                row[0] == "Exposure"):
        tbl.append(row)
add_table(doc, tbl)

emit_table("Supplementary Table S3. Survey-weighted Cox models for blood metals and mortality",
           "### Table 4.", "### Table 5.")
emit_table("Supplementary Table S4. Metal mixture analysis for stroke prevalence",
           "### Table 5.", "### Table 6.")
emit_table("Supplementary Table S5. Mercury-fish sensitivity analysis",
           "### Table 6.", None)

page_break(doc)
heading(doc, "Supplementary Table S6. Sensitivity analyses: seafood-adjusted mercury-cerebrovascular mortality and eGFR-adjusted cadmium models", size=11)
import csv as _csv
rows6 = [["Analysis", "Estimate (95% CI)", "P value"]]
with open(rf"{BASE}/reviewer_sensitivity_analyses.csv", encoding="utf-8") as fh:
    for r0 in list(_csv.DictReader(fh)):
        est = f"HR={float(r0['HR']):.2f} ({float(r0['lo']):.2f}-{float(r0['hi']):.2f})" if "mort" in r0["analysis"] or "cbv" in r0["analysis"] else f"OR={float(r0['OR']):.2f} ({float(r0['lo']):.2f}-{float(r0['hi']):.2f})"
        rows6.append([r0["analysis"], est, f"{float(r0['P']):.3g}"])
_t = add_table(doc, rows6)
para(doc, "M6: mercury-cerebrovascular mortality Cox models (n=26,232 restricted to complete dietary data; 199 events). M7a: cadmium-stroke logistic models (n=31,124). M7b: cadmium-all-cause-mortality Cox models (n=31,096; 5,649 deaths). eGFR, estimated glomerular filtration rate (mL/min/1.73 m2).")
para(doc, "")
heading(doc, "Supplementary Figure S1", size=11)
para(doc, "Relative weights of blood lead, cadmium, and mercury in the metal mixture associated with stroke prevalence (survey-weighted quantile g-computation). Mixture odds ratio per quartile increment = 1.20 (95% CI 1.00–1.43, P=0.046). Cadmium contributed 55.5% of the positive weight; mercury showed a negative contribution. (File: figS1_mixture_weights.png)")
doc.save(rf"{SUB}/JoS_Supplementary.docx")
print("saved JoS_Supplementary.docx")
