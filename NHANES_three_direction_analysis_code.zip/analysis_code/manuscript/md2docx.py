# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""把稿件 Markdown 转成可投稿的 docx（标题层级、正文、表格、参考文献）。"""
import re
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH

SRC = os.path.join(OUT, "manuscript/NHANES_stroke_manuscript.md")
DST = os.path.join(OUT, "manuscript/NHANES_stroke_manuscript.docx")

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(11)
st.element.rPr.rFonts.set(
    __import__("docx").oxml.ns.qn("w:eastAsia"), "宋体")
doc.styles["Normal"].paragraph_format.space_after = Pt(6)


def para(text, size=11, bold=False, italic=False, align=None, space_after=6):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.italic = italic
    r.font.size = Pt(size)
    r.font.color.rgb = RGBColor(0, 0, 0)
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_rich(line, size=11):
    """处理 **粗体** 行内标记"""
    p = doc.add_paragraph()
    for seg in re.split(r"(\*\*[^*]+\*\*)", line):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2])
            r.bold = True
        else:
            r = p.add_run(seg)
        r.font.size = Pt(size)
    p.paragraph_format.space_after = Pt(6)
    return p


lines = open(SRC, encoding="utf-8").read().split("\n")
i = 0
n = len(lines)
while i < n:
    ln = lines[i].rstrip()
    stripped = ln.strip()

    if stripped in ("---",):
        i += 1
        continue

    if stripped.startswith("# "):
        para(stripped[2:], size=16, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=10)
    elif stripped.startswith("## "):
        para(stripped[3:], size=14, bold=True, space_after=8)
    elif stripped.startswith("### "):
        para(stripped[4:], size=12, bold=True, space_after=6)
    elif stripped.startswith("#### "):
        para(stripped[5:], size=11, bold=True, space_after=4)
    elif stripped.startswith("|"):
        # 收集表格
        tbl = []
        while i < n and lines[i].strip().startswith("|"):
            row = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            tbl.append(row)
            i += 1
        # 过滤分隔行
        tbl = [r for r in tbl if not all(set(c) <= set("-: ") for c in r)]
        if tbl:
            ncols = max(len(r) for r in tbl)
            t = doc.add_table(rows=len(tbl), cols=ncols)
            t.style = "Table Grid"
            for ri, row in enumerate(tbl):
                for ci in range(ncols):
                    cell = t.cell(ri, ci)
                    txt = row[ci] if ci < len(row) else ""
                    txt = txt.replace("<br>", "\n")
                    cell.text = ""
                    p = cell.paragraphs[0]
                    for seg in re.split(r"(\*\*[^*]+\*\*)", txt):
                        if not seg:
                            continue
                        if seg.startswith("**") and seg.endswith("**"):
                            rr = p.add_run(seg[2:-2]); rr.bold = True
                        else:
                            rr = p.add_run(seg)
                        rr.font.size = Pt(9)
                    if ri == 0:
                        for rr in p.runs:
                            rr.bold = True
            doc.add_paragraph()
        continue
    elif stripped.startswith("- ") or stripped.startswith("* "):
        p = add_rich("• " + stripped[2:], size=11)
    elif re.match(r"^\d+\.\s", stripped):
        add_rich(stripped, size=11)
    elif stripped == "":
        i += 1
        continue
    else:
        add_rich(stripped, size=11)
    i += 1

doc.save(DST)
print("saved", DST)
