# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""从 EN 稿重组为 Journal of Stroke 投稿格式主文档（匿名正文 + 图注 + 表格）"""
import re

SRC = os.path.join(OUT, "manuscript/NHANES_stroke_manuscript_EN.md")
DST = os.path.join(OUT, "submission_JoS/JoS_Main_Manuscript.md")

t = open(SRC, encoding="utf-8").read()
lines = t.split("\n")


def block(start_pat, end_pat):
    i = next(k for k, l in enumerate(lines) if re.match(start_pat, l))
    j = next((k for k in range(i + 1, len(lines)) if re.match(end_pat, lines[k])), len(lines))
    return lines[i + 1:j]


intro = block(r"^## 1\. Introduction", r"^## 2\. Methods")
methods = block(r"^## 2\. Methods", r"^## 3\. Results")
results = block(r"^## 3\. Results", r"^## 4\. Discussion")
disc = block(r"^## 4\. Discussion", r"^## References")

def subheads_to_bold(block_lines, drop=False):
    out = []
    for l in block_lines:
        m = re.match(r"^### [\d.]+ (.+)$", l.strip())
        if m:
            if drop:
                continue
            out.append("**" + m.group(1) + "**")
            out.append("")
        else:
            out.append(l)
    # 压缩连续空行
    res, prev_blank = [], False
    for l in out:
        if l.strip() == "":
            if not prev_blank:
                res.append("")
            prev_blank = True
        else:
            res.append(l); prev_blank = False
    return res


intro_b = [l for l in intro if l.strip() and not l.startswith("---")]
methods_b = subheads_to_bold(methods)
results_b = subheads_to_bold(results)

# 正文引用重新编号：Cox 表/混合表/汞-鱼表移入 supplement，图号按主文 4 图重排
def renumber_refs(txt_lines):
    joined = "\n".join(txt_lines)
    joined = joined.replace("**Table 4** and Figure 6", "Supplementary Table S3 and Figure 4")
    joined = joined.replace("**Table 5** and Figure 4", "Supplementary Table S4 and Supplementary Figure S1")
    joined = joined.replace("**Table 6**", "Supplementary Table S5")
    return joined.split("\n")

results_b = renumber_refs(results_b)

# Discussion：去掉 4.1-4.5 子标题；4.6 Conclusions 单独抽出
disc_lines = disc
concl_idx = next(k for k, l in enumerate(disc_lines) if re.match(r"^### 4\.6 Conclusions", l))
concl = disc_lines[concl_idx + 1:]
disc_body = disc_lines[:concl_idx]
disc_b = subheads_to_bold(disc_body, drop=True)
concl_b = [l for l in concl if l.strip() and not l.startswith("---")]

# ---- 结构式摘要（≤250 词）----
abstract = """**Background and Purpose**  Whether environmental metal exposure contributes to stroke risk beyond conventional metabolic and inflammatory markers remains unclear, and the direction of the mercury-stroke association is contested. We compared blood lead, cadmium, and mercury with composite inflammatory and insulin-resistance indices in relation to stroke, and examined mortality follow-up.

**Methods**  Among 53,459 adults in NHANES 1999-2018, we fitted survey-weighted logistic models for self-reported stroke, survey-weighted Cox models for National Death Index-linked mortality (through December 2019), and quantile g-computation for the metal mixture. Seafood intake was added to the mercury models to test seafood-derived confounding (the "mercury-fish" paradox).

**Results**  Blood cadmium showed the strongest dose-response: the highest versus lowest quartile odds ratio was 1.86 (95% CI 1.31-2.64), with significant non-linearity (P=0.004). The metal mixture was associated with stroke (odds ratio 1.20 per quartile), dominated by cadmium (55.5% of positive weight). Blood mercury was inversely associated with stroke (odds ratio 0.80 per SD); adjusting for seafood and n-3 intake attenuated it by only 3.6%-8.3%. Cadmium predicted cardiovascular (hazard ratio 1.16) and coronary (1.18) mortality but not cerebrovascular mortality (0.97; 199 events). Inflammatory indices showed weak associations and triglyceride-glucose indices lost significance after adjustment. Cadmium effects were strongest in never-smokers.

**Conclusions**  Low-level cadmium exposure is associated with stroke independently of conventional risk factors, dominates the metal mixture, and predicts cardiovascular mortality; the cross-sectional stroke association and the inverse mercury association warrant confirmation in incident-stroke cohorts, and the null cerebrovascular-mortality finding suggests that cadmium stratification may operate primarily through coronary rather than stroke-specific pathways."""

kw = "Stroke; Cadmium; Lead; Mercury; Environmental Exposure; Metals, Heavy"

# ---- Methods 末尾伦理声明 ----
ethics = """
**Ethics statement.** The NHANES protocol was approved by the National Center for Health Statistics Ethics Review Board, and all participants provided written informed consent. The present analysis used de-identified, publicly available data and was exempt from further institutional review. [IRB approval number: TBD]"""

# ---- 主文 Table 2：仅金属 ----
def extract_table(start_title, end_title):
    i = t.find(start_title)
    j = t.find(end_title)
    blk = t[i:j]
    # 只保留 markdown 表格行
    tbl = [l for l in blk.split("\n") if l.strip().startswith("|")]
    return tbl


tbl1 = extract_table("### Table 1.", "### Table 2.")
# 金属表：从原 Table 2 提取表头 + Metals 块行
tbl2_full = extract_table("### Table 2.", "### Table 3.")
hdr = tbl2_full[:2]
metal_rows = [l for l in tbl2_full[2:] if "Metals" in l or "Blood mercury" in l]
# 清理：保留 Metals 分组标题行与三个金属数据行
metal_rows = [l for l in tbl2_full[2:] if l.startswith("| **Metals") or l.startswith("| Blood ")]
tbl2 = hdr + metal_rows
tbl2 = hdr + metal_rows

tbl3 = extract_table("### Table 3.", "### Table 4.")

# ---- Vancouver 参考文献 ----
refs = """1. GBD 2021 Stroke Risk Factor Collaborators. Global, regional, and national burden of stroke and its risk factors, 1990-2021: a systematic analysis for the Global Burden of Disease Study 2021. Lancet Neurol 2024;23:973-1003.
2. Lamas GA, Bhatnagar A, Jones MR, Mann KK, Nasir K, Tellez-Plaza M, et al. Contaminant metals as cardiovascular risk factors: a scientific statement from the American Heart Association. J Am Heart Assoc 2023;12:e029852.
3. Huang X, Wu Y, Lu Y. Single and mixed effects of seven heavy metals on stroke risk: 11,803 adults from National Health and Nutrition Examination Survey (NHANES). Front Nutr 2025;12:1524099.
4. Zuo W, Yang X. A machine learning model predicts stroke associated with blood cadmium level. Sci Rep 2024;14:14739.
5. Menke A, Muntner P, Silbergeld EK, Platz EA, Guallar E. Cadmium levels in urine and mortality among U.S. adults. Environ Health Perspect 2009;117:190-6.
6. Tellez-Plaza M, Guallar E, Fabsitz RR, Howard BV, Umans JG, Francesconi KA, et al. Cadmium exposure and incident peripheral arterial disease. Circ Cardiovasc Qual Outcomes 2013;6:626-33.
7. Liu G, Qian H, Wang L, Wu W. Systemic immune-inflammation index and its association with the prevalence of stroke in the United States population: a cross-sectional study using the NHANES database. Rev Cardiovasc Med 2024;25:130.
8. Tian A, Zheng Y, Jin J, Huang C. Association of systemic inflammatory response index and stroke: a cross-sectional study of NHANES, 2005-2018. Front Neurol 2025;16:1538352.
9. Angkananard T, Anothaisintawee T, McEvoy M, Attia J, Thakkinstian A. Neutrophil lymphocyte ratio and cardiovascular disease risk: a systematic review and meta-analysis. Biomed Res Int 2018;2018:2703518.
10. Sawaf B, Swed S, Alibrahim H, Bohsas H, Dave T, Nasif MN, et al. Triglyceride-glucose index as predictor for hypertension, CHD and STROKE risk among non-diabetic patients: a NHANES cross-sectional study 2001-2020. J Epidemiol Glob Health 2024;14:1152-66.
11. Li J, Lin F, Xiao L, Liu C, Li Y, Deng Y. Triglyceride-glucose markers and obesity composites in relation to stroke diagnosis and mortality: a population-representative analysis. J King Saud Univ Sci 2026;38:185.
12. Tellez-Plaza M, Navas-Acien A, Crainiceanu CM, Guallar E. Cadmium exposure and hypertension in the 1999-2004 National Health and Nutrition Examination Survey (NHANES). Environ Health Perspect 2008;116:51-6.
13. Li P, Feng X, Qiu G. Methylmercury exposure and health effects from rice and fish consumption: a review. Int J Environ Res Public Health 2010;7:2666-91.
14. Sun Y, Liu B, Rong S, Zhang J, Du Y, Xu G, et al. Association of seafood consumption and mercury exposure with cardiovascular and all-cause mortality among US adults. JAMA Netw Open 2021;4:e2136367.
15. Tack RWP, Senff JR, Kimball TN, Prapiadou S, Tan BYQ, Yechoor N, et al. Reliability and validity of self-reported risk factors for stroke and dementia. J Am Heart Assoc 2025;14:e038730."""

# ---- 图注 ----
fig_legends = """**Figure 1.** Study population selection and analytic sub-samples. NHANES, National Health and Nutrition Examination Survey; TyG, triglyceride-glucose.

**Figure 2.** Associations between blood metals and stroke prevalence (survey-weighted logistic regression, fully adjusted model). Estimates are odds ratios per 1 standard deviation increment and by quartile (Q2-Q4 versus Q1), with 95% confidence intervals; the "P trend" rows show the per-quartile-increment odds ratio from the ordinal trend model. Pb, lead; Cd, cadmium; Hg, mercury.

**Figure 3.** Restricted cubic splines for the association of blood lead (A) and blood cadmium (B) with stroke prevalence, adjusted for the full covariate set. Solid lines represent odds ratios referenced to the median concentration; shaded bands represent 95% confidence intervals.

**Figure 4.** Survey-weighted Cox models for blood metals and mortality (all-cause, cardiovascular, cerebrovascular, and coronary heart disease), per 1 standard deviation increment, fully adjusted. Analyses were restricted to mortality-eligible participants (n = 26,208; median follow-up 9.0 years). Red points denote P < 0.05; grey points denote non-significant estimates."""

# ---- 组装 ----
parts = []
parts.append("# Blood cadmium, lead, and mercury in relation to stroke and mortality in US adults: NHANES 1999\u20132018\n")
parts.append("Running title: Cadmium and stroke in NHANES 1999\u20132018\n")
parts.append("Title: 99 characters (including spaces) | Main-text word count: 4,125 | Figures: 4 | Tables: 3\n")
parts.append("\n---\n")
parts.append("\n## Abstract\n")
parts.append(abstract)
parts.append("\n\n**Keywords:** " + kw + "\n")
parts.append("\n---\n")
parts.append("\n## Introduction\n")
parts.append("\n".join(intro_b))
parts.append("\n\n## Methods\n")
parts.append("\n".join(methods_b))
parts.append(ethics)
parts.append("\n\n## Results\n")
parts.append("\n".join(results_b))
parts.append("\n\n## Discussion\n")
parts.append("\n".join(disc_b))
parts.append("\n\n## Conclusions\n")
parts.append("\n".join(concl_b))
parts.append("\n\n---\n\n## Acknowledgments and Sources of Funding\n")
parts.append("This work was supported by the China Postdoctoral Science Foundation (Grant No. 2025M772029) and the Peking University People's Hospital Talent Introduction Scientific Research Launch Fund (2022-T-02).")
parts.append("\n\n## Conflicts of Interest\n")
parts.append("The authors declare no conflicts of interest related to this study. [TBD]")
parts.append("\n\n---\n\n## References\n")
parts.append(refs)
parts.append("\n\n---\n\n## Figure Legends\n")
parts.append(fig_legends)
parts.append("\n\n---\n\n## Tables\n")
parts.append("\n**Table 1.** Weighted baseline characteristics of the study population by stroke status (NHANES 1999\u20132018). Weighted stroke prevalence was approximately 3%. Lipid and hs-CRP values in prevalent stroke are susceptible to post-event statin treatment and lifestyle change.\n")
parts.append("\n".join(tbl1))
parts.append("\n\n[PAGEBREAK]\n\n**Table 2.** Associations of blood metals with stroke prevalence (survey-weighted logistic regression)\n")
parts.append("\n".join(tbl2))
parts.append("\n\n[PAGEBREAK]\n\n**Table 3.** Subgroup analysis of the association between blood cadmium (per SD) and stroke prevalence\n")
parts.append("\n".join(tbl3))

import os
os.makedirs(os.path.dirname(DST), exist_ok=True)
open(DST, "w", encoding="utf-8").write("\n".join(parts))

# 正文字数统计（Introduction-Conclusions，不含声明/文献/图注/表）
body_text = "\n".join(intro_b + methods_b + results_b + disc_b + concl_b)
wc = len(re.sub(r"[*#\u2019'-\[\]():;,.%0-9]", " ", body_text).split())
print("saved", DST)
print("approx main-text word count (intro-conclusions):", wc)
