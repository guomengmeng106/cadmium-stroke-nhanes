# 重画森林图：统一 per SD 标签，每方向一张，干净四行
library(dplyr); library(ggplot2)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

RES <- read.csv(file.path(OUT, "or_results.csv"), fileEncoding = "UTF-8")
fp <- RES %>% filter(model == "Model 2", term != "P trend") %>%
  mutate(term = ifelse(grepl("per SD", term), "per SD increase", term),
         term = factor(term, levels = c("per SD increase", "Q2 vs Q1", "Q3 vs Q1", "Q4 vs Q1")))
for (dirn in unique(fp$direction)) {
  pd <- fp %>% filter(direction == dirn)
  p <- ggplot(pd, aes(x = OR, y = term)) +
    geom_vline(xintercept = 1, linetype = 2, color = "grey50") +
    geom_errorbar(aes(xmin = lo, xmax = hi), width = 0.2, color = "#2C7FB8", orientation = "y") +
    geom_point(size = 2.2, color = "#D7301F") +
    scale_x_log10() +
    facet_wrap(~exposure, scales = "free_x", ncol = 2) +
    labs(title = paste0(dirn, " indicators vs stroke (survey-weighted logistic, Model 2)"),
         x = "OR (95% CI, log scale)", y = NULL) +
    theme_bw(base_size = 11)
  ggsave(file.path(OUT, "figures", paste0("forest_", dirn, ".png")), p, width = 10, height = 5, dpi = 150)
  cat("redrawn", dirn, "\n")
}
