# -*- coding: utf-8 -*-
# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
import os
OUT = os.environ.get("NHANES_OUT", r"C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")
BASE = os.environ.get("NHANES_DATA", r"D:/数据库/NHANME/1988-2018NHANES数据/清洗后和未清洗的数据/清洗")

"""第二轮提取：在原有底表基础上加入 NDI 死亡随访变量 + 膳食海鲜/n-3 摄入变量"""
import polars as pl
import time

t0 = time.time()
# ---- mortality ----
lf = pl.scan_csv(f"{BASE}/10.mortality_clean.csv", infer_schema_length=0, null_values=["NA", ""])
have = set(lf.collect_schema().names())
mort_cols = ["SEQN_new", "ELIGSTAT", "MORTSTAT", "UCOD_LEADING", "PERMTH_EXM", "PERMTH_INT"]
mort = lf.select([c for c in mort_cols if c in have]).collect(streaming=True)
print("mortality:", mort.shape)

# ---- dietary (海鲜/n-3) ----
diet_cols = ["SEQN_new", "DRXT_PF_SEAFD_HI", "DRXT_PF_SEAFD_LOW", "DRXT_PF_TOTAL",
             "DRXTP205", "DRXTP226"]
lf2 = pl.scan_csv(f"{BASE}/9.dietary_clean.csv", infer_schema_length=0, null_values=["NA", ""])
have2 = set(lf2.collect_schema().names())
miss2 = [c for c in diet_cols if c not in have2]
if miss2:
    print("[WARN] dietary missing:", miss2)
keep = [c for c in diet_cols if c in have2]
# 膳食表按 SEQN_new × survey_day 展开为"每人每天一行" -> 先数值化，再按人取两天均值
diet = lf2.select(keep).collect()
NUM = [c for c in keep if c != "SEQN_new"]
diet = diet.with_columns([pl.col(c).cast(pl.Float64, strict=False) for c in NUM])
diet = (diet.group_by("SEQN_new")
        .agg([pl.col(c).mean().alias(c) for c in NUM]))
print("dietary (per person, 2-day mean):", diet.shape)

# ---- 合并到已有底表 ----
base = pl.read_parquet(f"{OUT}/analysis_base.parquet")
print("old base:", base.shape)
new = base.join(mort, on="SEQN_new", how="left").join(diet, on="SEQN_new", how="left")
print("new base:", new.shape)

# 类型转换
casts = ["ELIGSTAT", "MORTSTAT", "UCOD_LEADING", "PERMTH_EXM", "PERMTH_INT",
         "DRXT_PF_SEAFD_HI", "DRXT_PF_SEAFD_LOW", "DRXT_PF_TOTAL", "DRXTP205", "DRXTP226"]
new = new.with_columns([
    pl.col(c).cast(pl.Float64, strict=False).alias(c) for c in casts if c in new.columns
])

# ---- 覆盖率检查 ----
num = ["SDDSRVYR", "RIDAGEYR"] + casts
new = new.with_columns([pl.col(c).cast(pl.Float64, strict=False).alias(c)
                        for c in num if c in new.columns])
print("\n=== mortality 覆盖率（限 1999-2018 成人）===")
ad = new.filter((pl.col("SDDSRVYR") >= 1) & (pl.col("RIDAGEYR") >= 20))
print("成人 1999-2018 n =", ad.height)
print("ELIGSTAT 分布:", ad.group_by("ELIGSTAT").len().sort("ELIGSTAT").to_dicts())
print("MORTSTAT 分布:", ad.group_by("MORTSTAT").len().sort("MORTSTAT").to_dicts())
print("\n=== UCOD_LEADING 分布（已死亡者）===")
print(ad.filter(pl.col("MORTSTAT") == 1).group_by("UCOD_LEADING").len().sort("UCOD_LEADING").to_dicts())

print("\n=== 海鲜/n-3 膳食覆盖（按周期非空率, 成人）===")
for c in ["DRXT_PF_SEAFD_HI", "DRXT_PF_SEAFD_LOW", "DRXTP205", "DRXTP226"]:
    if c in ad.columns:
        g = ad.group_by("SDDSRVYR").agg(
            (pl.col(c).is_not_null().sum()).alias("nn"), pl.len().alias("tot")
        ).sort("SDDSRVYR")
        g = g.with_columns((pl.col("nn") / pl.col("tot") * 100).round(1).alias("pct_nonnull"))
        print(f"--- {c}")
        print(g)

new.write_parquet(f"{OUT}/analysis_base2.parquet")
print(f"\nsaved analysis_base2.parquet  ({time.time()-t0:.0f}s)  shape={new.shape}")
