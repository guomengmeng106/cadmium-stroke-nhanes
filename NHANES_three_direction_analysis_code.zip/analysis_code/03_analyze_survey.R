# NHANES 1999-2018: 三方向暴露与卒中的复杂抽样加权关联分析
library(arrow)
library(dplyr)
library(survey)
library(ggplot2)

# ===== 路径配置：可用环境变量覆盖，迁移到其他机器无需改动代码 =====
OUT <- Sys.getenv("NHANES_OUT", "C:/Users/wangx/WorkBuddy/2026-09-16-22-30-34/outputs/nhanes_analysis")

dir.create(file.path(OUT, "figures"), showWarnings = FALSE, recursive = TRUE)
df <- read_parquet(file.path(OUT, "analysis_clean.parquet"))

df <- df %>% mutate(
  age = RIDAGEYR,
  female = factor(female, levels = 0:1, labels = c("Male", "Female")),
  race = factor(ifelse(RIDRETH1 %in% 1:5, RIDRETH1, NA), levels = 1:5,
                labels = c("Mexican American", "Other Hispanic", "Non-Hispanic White",
                           "Non-Hispanic Black", "Other")),
  educ = factor(ifelse(DMDEDUC2 %in% 1:5, DMDEDUC2, NA), levels = 1:5,
                labels = c("<9th", "9-11th", "High school", "Some college", "College+")),
  pir = INDFMPIR, bmi = BMXBMI,
  smoke = factor(smoke, levels = c("non", "former_passive", "current")),
  diabetes = factor(diabetes, levels = 0:1, labels = c("No", "Yes")),
  hyperten = factor(hyperten, levels = 0:1, labels = c("No", "Yes")),
  alcohol = factor(alcohol, levels = 0:1, labels = c("No", "Yes"))
)

COV1 <- c("age", "female", "race")
COV2 <- c(COV1, "educ", "pir", "bmi", "smoke", "diabetes", "hyperten", "alcohol")

prep <- function(data, expvar, wtvar) {
  req <- c(expvar, wtvar, "stroke", COV2, "SDMVPSU", "SDMVSTRA")
  dd <- data %>% filter(if_all(all_of(req), ~ !is.na(.x))) %>% filter(.data[[wtvar]] > 0)
  qs <- unique(quantile(dd[[expvar]], c(0, .25, .5, .75, 1), na.rm = TRUE))
  if (length(qs) == 5) {
    dd$expQ <- cut(dd[[expvar]], qs, include.lowest = TRUE, labels = c("Q1", "Q2", "Q3", "Q4"))
  } else {
    dd$expQ <- cut(dd[[expvar]], qs, include.lowest = TRUE)
  }
  dd$expQn <- as.numeric(dd$expQ)
  sdx <- sd(dd[[expvar]], na.rm = TRUE)
  dd$expSD <- (dd[[expvar]]) / sdx
  dd$sdx <- sdx
  dd
}

fit_models <- function(dd, wtvar) {
  des <- svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA,
                   weights = as.formula(paste0("~", wtvar)), data = dd, nest = TRUE)
  f0 <- "stroke ~ expSD"
  f1 <- paste("stroke ~ expSD +", paste(COV1, collapse = " + "))
  f2 <- paste("stroke ~ expSD +", paste(COV2, collapse = " + "))
  fq <- paste("stroke ~ expQ +", paste(COV2, collapse = " + "))
  ft <- paste("stroke ~ expQn +", paste(COV2, collapse = " + "))
  m0 <- svyglm(as.formula(f0), design = des, family = quasibinomial())
  m1 <- svyglm(as.formula(f1), design = des, family = quasibinomial())
  m2 <- svyglm(as.formula(f2), design = des, family = quasibinomial())
  mq <- svyglm(as.formula(fq), design = des, family = quasibinomial())
  mt <- svyglm(as.formula(ft), design = des, family = quasibinomial())
  grab <- function(m, term, label, model) {
    s <- summary(m)$coefficients
    if (!(term %in% rownames(s))) return(NULL)
    b <- s[term, "Estimate"]; se <- s[term, "Std. Error"]; p <- s[term, "Pr(>|t|)"]
    data.frame(model = model, term = label, OR = exp(b),
               lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se), P = p)
  }
  sdx <- dd$sdx[1]
  rbind(
    grab(m0, "expSD", paste0("per SD (", round(sdx, 2), ")"), "Crude"),
    grab(m1, "expSD", paste0("per SD (", round(sdx, 2), ")"), "Model 1"),
    grab(m2, "expSD", paste0("per SD (", round(sdx, 2), ")"), "Model 2"),
    grab(mq, "expQQ2", "Q2 vs Q1", "Model 2"),
    grab(mq, "expQQ3", "Q3 vs Q1", "Model 2"),
    grab(mq, "expQQ4", "Q4 vs Q1", "Model 2"),
    grab(mt, "expQn", "P trend", "Model 2")
  )
}

fmt <- function(r) {
  ifelse(is.na(r$OR), "", sprintf("%.2f (%.2f-%.2f)%s", r$OR, r$lo, r$hi,
    ifelse(r$P < 0.001, "***", ifelse(r$P < 0.01, "**", ifelse(r$P < 0.05, "*", "")))))
}

DIRECTIONS <- list(
  TyG = list(exps = c("TyG", "TyG_BMI", "TyG_WC", "TyG_WHtR"), wt = "wt_tyg"),
  Inflammation = list(exps = c("SII", "SIRI", "NLR", "PLR", "MAR"), wt = "wt_mec"),
  Metals = list(exps = c("LBXBPB", "LBXBCD", "LBXTHG"), wt = "wt_pb")
)

all_res <- list()
for (dirn in names(DIRECTIONS)) {
  cfg <- DIRECTIONS[[dirn]]
  for (ev in cfg$exps) {
    cat(">>", dirn, ev, "\n")
    dd <- prep(df, ev, cfg$wt)
    res <- fit_models(dd, cfg$wt)
    res$direction <- dirn; res$exposure <- ev
    res$n <- nrow(dd); res$n_stroke <- sum(dd$stroke == 1)
    all_res[[paste(dirn, ev)]] <- res
  }
}
RES <- bind_rows(all_res)
RES$OR_CI <- fmt(RES)
write.csv(RES, file.path(OUT, "or_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")
cat("saved or_results.csv\n")

# ---------- 森林图（Model 2） ----------
fp <- RES %>% filter(model == "Model 2", term != "P trend") %>%
  mutate(term = factor(term, levels = c(paste0("per SD (", unique(sub(".*\\((.*)\\)", "\\1", term)), ")"), "Q2 vs Q1", "Q3 vs Q1", "Q4 vs Q1")))
for (dirn in unique(fp$direction)) {
  pd <- fp %>% filter(direction == dirn)
  p <- ggplot(pd, aes(x = OR, y = term)) +
    geom_vline(xintercept = 1, linetype = 2, color = "grey50") +
    geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.2, color = "#2C7FB8") +
    geom_point(size = 2.2, color = "#D7301F") +
    scale_x_log10() +
    facet_wrap(~exposure, scales = "free_x", ncol = 2) +
    labs(title = paste0(dirn, " indicators vs stroke (weighted, Model 2)"),
         x = "OR (95% CI, log scale)", y = NULL) +
    theme_bw(base_size = 11)
  ggsave(file.path(OUT, "figures", paste0("forest_", dirn, ".png")), p, width = 10, height = 6, dpi = 150)
}
cat("saved forest plots\n")

# ---------- RCS ----------
# 注：RCS 曲线与非线性检验请用 04_rcs_nonlinearity.R。
# 那里使用「训练数据的 knots/Boundary.knots 在预测网格上重建 ns basis」的正确实现；
# 早期版本在网格上直接调用 ns() 会因 knots 不同导致 basis 维度不匹配而报错，
# 且会画出形态错误的曲线（如铅的假性钟形下跌）。此处不再重复实现。
cat("DONE
")
